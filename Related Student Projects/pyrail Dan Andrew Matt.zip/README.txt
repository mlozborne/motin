--------------------------------- PYRAIL --------------------------------------

Developers: Dan Bentson, Andrew Larsen, Matthew Preucil

Current Version: 1.0
Last Revision: 6/9/2011

-------------------------------------------------------------------------------

Software Requirements:

  Python 2.7 or higher
  pyserial and WX libraries
  Train Simulator

Hardware Requirements:

  An awesome LocoNet model train system

-------------------------------------------------------------------------------

System Components and Run Configurations:

  The  TCP  server for throttles, the PyRail control system, and LocoNet    
  serial   communication.  This  component  is  the  LocoBufferServer.py
  file.  Execute  python LocoBufferServer.py -help  for  information  on
  running the server.

  Server Options: Filtered mode is required for using the  PyRail
                  control  system.  Running  in  unfiltered  mode 
                  provides an interface for stand-alone mode with
                  the TCP throttles.  In filtered mode, the first
                  connection recieved by the server MUST  by  the 
                  PyRail control system.

                  Run mode indicates the type  of train system to
                  be controlled.  0 is  standard, or the  LocoNet
                  train system.  1 is simulated, or  the software
                  simulator.

                  Serial information is  required if  running  in
                  standard  mode.  The  port  must be the correct
                  serial port  the LocoNet is  connected to.  The
                  method of determining this value varies between 
                  OS.  The baudrate is crucial and the default is
                  compatible with the LocoNet system.

                  *NOTE* -p in addition to specifying serial port,
                  specifies the port the simulator is using for
                  simulated mode.

                  Network information is required for both modes.
                  The host option should be the host of the 
                  software simulator.  The port, -P is the port 
                  you want the LocoBufferServer to accept 
                  connections on.                       
		  
  Server Arguments:
                   
                  port is either the serial port or the simulator
                  port.  Cannot be used with options.

    Example: python LocoBufferServer.py -m 1 - p 1400 - H localhost -f 1

  The PyRail control system, PyRail.py. This is the component that drives 
  the software. This must be connected to an instance of  the  LocoBuffer
  Server on startup. The name of a track layout xml file must be provided.

  PyRail Options: Network settings specify the location of the
  	 	  LocoBufferServer.

    Example: python PyRail.py -H localhost

  The admin throttle, SimpleThrottle.py.  This GUI application is self explanatory.

    Example: python SimpleThrottle.py

--------------------------------------------------------------------------------

  General Information:

  The layout xml files included are as follows:  LabLayout.xml - Train Lab
                                                 SimLayout.xml - Simulator

    -- Located in the resources directory.

  Two batch files for simple startup on windows: StartSim.bat
                                                 StartLab.bat

    -- Located in the resources directory.

      *NOTE* Verify the serial port in StartLab.bat  
  
  WX Library installer is included and must be installed.

  PySerial Library installer included and must be installed for serial operation.

   --To run the software without installing PySerial, comment out the import in
     LocoBufferServer.py

---------------------------------------------------------------------------------

  Non-Implemented Functionality:

  -- READ_XML message.  XML must be specified on startup (of PyRail.py) and cannot    be
     changed. Implementing this would require a thorough understanding of
     the way the Command Queue Manager and the Layout Manager are created
     and interact.

  -- MOVE_NEXT_SWITCH message.
     This message will be converted to a TRY_MOVE_AGAIN message and sent to 
     the trains.

  -- PUT_TRAIN_INFORMATION message.
     Converted to TRY_MOVE_AGAIN as above.

  -- Throttle does not save log information as a text file.

  -- DIRF messages work in simulator but lights, horn, bell, mute may have
     problems in the lab.

  Implemented Functionality:

  -- Should be everything else, however we don't claim that there are no bugs. :)  Enjoy!

----------------------------------------------------------------------------------

