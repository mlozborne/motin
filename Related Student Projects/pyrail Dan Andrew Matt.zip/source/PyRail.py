########################################################################
#                                                                      #
#  #######                 #######                                     # 
#  ########               ##########                                   #
#  ##     ##  ##      ##  ###     ###  ############  ######  ####      #
#  ##     ##  ###    ###  ###     ###  ############  ######  ####      #
#  ########    ###  ###   ###    ###   ####    ####          ####      #
#  ######       ######    ###  ####    ####    ####  ######  ####      #      
#  ###           ####     ########     ############  ######  ####      #
#  ###           ###      ###  ###     ####    ####  ######  ####      #
#  ###          ###       ###  ###     ####    ####  ######  ####      #
#  ###         ###        ###   ###    ####    ####  ######  ########  #
#  ###        ###         ###    ###   ####    ####  ######  ########  #
#                                                                      #
########################################################################

import threading
import socket
from LayoutLib import *
from LocoLib import *
from sys import stdout as SO
from sys import stderr as SE

from pyrailobjects import *

### Class: PyDriver
### Purpose: Provides all initialization logic

class PyDriver:

    def __init__(self, locoComObj):
        self.lt = locoComObj
        self.alive = True
        self.layoutFname = None
        
    def run(self):
        print "Welcome to PyRail, an amazing train control system!"
        if self.layoutFname is None:
            fname = raw_input('Enter the name of an XML file to load: ')
            #if fname valid then ->
            self.layoutFname = fname
        self.qm = CommandQueueManager(self.lt)
        self.lm = LayoutManager(self.layoutFname, self.qm)
        self.qm.registerLayoutManager(self.lm)
        self.qm.readerThread.start()
        #self.lm.cmdQM = self.qm
        #numTrains = raw_input('Enter the number of trains: ')
        #if valid data
        #for i in range(1, numTrains):
            # create a train and add it
        #    break
        # when all done with init data
        pysys = PyrailSystem(self.lt, self.lm, self.qm)
        while self.alive:
            cmd = raw_input('>>> ')
            self.handleCmd(cmd)
        return pysys.shutDown()

    def handleCmd(self, cmd):
        if cmd == 'q':
            self.alive = False

class PyrailSystem:

    def __init__(self, locoComObj, layoutManager, cmdQManager):
        self.locoCom = locoComObj
        self.layoutManager = layoutManager
        self.cmdQM = cmdQManager

    def shutDown(self):
        # Close all threads and connections then return true
        SE.write("Closing LocoBuffer Communication...")
        self.locoCom.close()
        SE.write("done\nShutting down CQM...")
        self.cmdQM.shutDown()
        SE.write("done\nShutting down LM...")
        self.layoutManager.shutDown()
        SE.write("done\n")
        return True

if __name__ == "__main__":
    import optparse

    optparser = optparse.OptionParser(
        usage = "%prog [options]",
        description = "Model train system control program")
    
    group = optparse.OptionGroup(optparser, "Network settings", "Network configuration")
    optparser.add_option_group(group)
    
    group.add_option("-p", "--port", 
                     dest = "port", 
                     action = "store", 
                     type = "int", 
                     help = "LocoBufferServer port", 
                     default = 7245)
    
    group.add_option("-H", "--host", 
                     dest = "host", 
                     action = "store", 
                     help = "LocoBufferServer IP", 
                     default = 'localhost')
    
    (options, args) = optparser.parse_args()
    
    # First lets connect to the LocoBufferServer using a LocoTransmitter
    
    # Create the socket
    socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
#    try:
    socket.connect((options.host, options.port))
    # Create the transmitter
    lt = LocoTransmitter(socket)
    driver = PyDriver(lt)
    driver.run()
    SO.write("Goodbye!\n")
#    except Exception as inst:
#        SE.write("Could not connect to the Loco Server at host: %s on port: %s\nError: %s" %  (options.host, options.port, inst))

