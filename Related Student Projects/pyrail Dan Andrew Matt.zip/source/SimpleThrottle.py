import socket
import operator
import threading, thread
import os, sys, re
import time
import string
import wx, wx.html
from LocoLib import *
import helpers

class mySettings:
    def __init__(self):
        self.settings = {}
        self.settings['Host'] = 'localhost'
        self.settings['Port'] = '7245'
        self.soc = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.connected = False
        self.lt = None
        
class myTrain:
    def __init__(self):
        self.t = {}
        self.t['name'] = '1111'
        self.t['dir'] = 0
        self.t['spd'] = 0
        self.t['light'] = 0
        self.t['bell'] = 0
        self.t['horn'] = 0
        self.t['mute'] = '0'

#global sets
sets = mySettings()
#switches = mySwitches()
trains = {}


#for i in range(1,5):
#    trains[i] = myTrain()
        
#Class to set up a frame. This frame holds the menu and panel of buttons.
class myFrame(wx.Frame):
    def __init__(self, parent, id):
        super(myFrame, self).__init__(parent,id,title="SimpleThrottle",size=(640,700))
        self.size = self.GetClientSize()
        self.Bind(wx.EVT_SIZING, self.OnResize)
        menuBar = wx.MenuBar()
        menu1 = wx.Menu()
        menu1.Append(101,"&Connect")
        self.Bind(wx.EVT_MENU, self.OnConnect, id = 101)
        menu1.Append(102,"&Quit")
        self.Bind(wx.EVT_MENU, self.OnQuit, id = 102)
        menuBar.Append(menu1, "&File")
        self.SetMenuBar(menuBar)
        
        self.panel = myPanel(self, -1)
        self.Show(True)

    def OnResize(self, event):
        self.Refresh()

    def OnConnect(self, event):
        dlg = connectBox(self,sets.soc)
        dlg.ShowModal()
        dlg.Destroy()
        
    def OnQuit(self, event):
        self.Close()

class connectBox(wx.Dialog):
    def __init__(self,parent,socket):
        wx.Dialog.__init__(self, parent, -1, "Connect",size=(280,240),
            style=wx.DEFAULT_DIALOG_STYLE|wx.RESIZE_BORDER|wx.TAB_TRAVERSAL)
        
        self.parent = parent
        self.s = socket
        panel = wx.Panel(self, -1)
        vbox = wx.BoxSizer(wx.VERTICAL)
        
        wx.StaticBox(panel, -1, 'Server Info', pos=(5,5),size=(250,150))
        self.hostlbl = wx.StaticText(panel, -1, "Host: ",
                                      pos=(15,30))
        self.hosttxt = wx.TextCtrl(panel, -1, sets.settings['Host'], 
                                    style=wx.TE_PROCESS_ENTER,
                                    pos=(55,30),size=(190,-1))
        self.Bind(wx.EVT_TEXT_ENTER,self.OnEnter,self.hosttxt)
        self.portlbl = wx.StaticText(panel, -1, "Port: ",
                                      pos=(15,55))
        self.porttxt = wx.TextCtrl(panel, -1, sets.settings['Port'],
                                    style=wx.TE_PROCESS_ENTER,
                                    pos=(55,55),size=(190,-1))
        self.Bind(wx.EVT_TEXT_ENTER,self.OnEnter,self.porttxt)
        hbox = wx.BoxSizer(wx.HORIZONTAL)
        okButton = wx.Button(self, -1, 'Ok', size=(70,30))
        okButton.SetDefault()
        self.Bind(wx.EVT_BUTTON,self.OnOk,okButton)
        closeButton = wx.Button(self, -1, 'Close', size=(70,30))
        self.Bind(wx.EVT_BUTTON,self.OnClose,closeButton)

        self.temphost = self.hosttxt.GetValue()
        self.tempport = self.porttxt.GetValue()
  
        hbox.Add(okButton, 1)
        hbox.Add(closeButton, 1, wx.LEFT, 5)
        
        vbox.Add(panel)
        vbox.Add(hbox, 1, wx.ALIGN_CENTER | wx.TOP | wx.BOTTOM, 10)
        
        self.SetSizer(vbox)

    def OnEnter(self,event):
        self.OnOk(event)
        
    def OnOk(self,event):
        try:
            if (eval(self.porttxt.GetValue()) > 0):
                sets.settings['Host'] = self.hosttxt.GetValue()
                sets.settings['Port'] = self.porttxt.GetValue()
                sets.soc.connect((sets.settings['Host'],eval(sets.settings['Port'])))
                sets.connected = True
                sets.lt = LocoTransmitter(sets.soc)
                self.Close()
            else:
                wx.MessageBox('bad port!', 'Alert')
        except socket.error as (errno, errstring):
            wx.MessageBox('Connection failed!\n' + repr(errstring), 'Alert')

    def OnClose(self,event):
        sets.settings['Host'] = self.temphost
        sets.settings['Port'] = self.tempport
        self.parent.parent.Close()
        
class registerBox(wx.Dialog):
    def __init__(self,parent):
        wx.Dialog.__init__(self, parent, -1, "Register",size=(280,160),
            style=wx.DEFAULT_DIALOG_STYLE|wx.RESIZE_BORDER|wx.TAB_TRAVERSAL)
        self.parent = parent
        self.parent.donothing = True
        panel = wx.Panel(self, -1)
        vbox = wx.BoxSizer(wx.VERTICAL)
        
        wx.StaticBox(panel,-1,'Address Info', pos=(5,5),size=(250,75))
        self.addrlbl = wx.StaticText(panel, -1, "Address: ",
                                     pos=(15,30))
        self.addrtxt = wx.TextCtrl(panel, -1, self.parent.phys.GetLabel(),
                                    style=wx.TE_PROCESS_ENTER,
                                    pos=(60,30),size=(50,-1))
        self.Bind(wx.EVT_TEXT_ENTER,self.OnEnter,self.addrtxt)
        hbox = wx.BoxSizer(wx.HORIZONTAL)
        okButton = wx.Button(self, -1, 'Ok', size=(70,30))
        okButton.SetDefault()
        self.Bind(wx.EVT_BUTTON,self.OnOk,okButton)
        closeButton = wx.Button(self, -1, 'Close', size=(70,30))
        self.Bind(wx.EVT_BUTTON,self.OnClose,closeButton)
        
        self.tempaddr = self.parent.phys
        
        hbox.Add(okButton, 1)
        hbox.Add(closeButton, 1, wx.LEFT, 5)
        
        vbox.Add(panel)
        vbox.Add(hbox, 1, wx.ALIGN_CENTER | wx.TOP | wx.BOTTOM, 10)
        
        self.SetSizer(vbox)
        
    def OnEnter(self,event):
        self.OnOk(event)
        
    def OnOk(self,event):
        if self.addrtxt.GetValue() == "":
            wx.MessageBox('No Address!','Alert')
        else:
            self.parent.donothing = False
            self.parent.phys.SetLabel(self.addrtxt.GetValue())
            self.Close()
            
    def OnClose(self,event):
        self.Close()
        
class initBox(wx.Dialog):
    def __init__(self,parent):
        wx.Dialog.__init__(self, parent, -1, "Initialize",size=(280,160),
            style=wx.DEFAULT_DIALOG_STYLE|wx.RESIZE_BORDER|wx.TAB_TRAVERSAL)
        self.parent = parent
        self.parent.donothing = True
        panel = wx.Panel(self, -1)
        vbox = wx.BoxSizer(wx.VERTICAL)
        
        wx.StaticBox(panel, -1,'Sensor Info', pos=(5,5),size=(250,75))
        self.sensorlbl = wx.StaticText(panel, -1, "Sensors: ",
                                       pos=(15,50))
        self.sensortxt = wx.TextCtrl(panel, -1, self.parent.initsensors.GetLabel(),
                                     style=wx.TE_PROCESS_ENTER,
                                     pos=(60,50),size=(180,-1))
        self.Bind(wx.EVT_TEXT_ENTER,self.OnEnter,self.sensortxt)
        
        self.addrlbl = wx.StaticText(panel, -1, "Address: ",
                                       pos=(15,30))
        self.addrtxt = wx.TextCtrl(panel, -1, self.parent.phys.GetLabel(),
                                     style=wx.TE_PROCESS_ENTER,
                                     pos=(60,30),size=(180,-1))
        self.Bind(wx.EVT_TEXT_ENTER,self.OnEnter,self.addrtxt)
        hbox = wx.BoxSizer(wx.HORIZONTAL)
        okButton = wx.Button(self, -1, 'Ok', size=(70,30))
        okButton.SetDefault()
        self.Bind(wx.EVT_BUTTON,self.OnOk,okButton)
        closeButton = wx.Button(self, -1, 'Close', size=(70,30))
        self.Bind(wx.EVT_BUTTON,self.OnClose,closeButton)
        
        hbox.Add(okButton, 1)
        hbox.Add(closeButton, 1, wx.LEFT, 5)
        
        vbox.Add(panel)
        vbox.Add(hbox, 1, wx.ALIGN_CENTER | wx.TOP | wx.BOTTOM, 10)
        
        self.SetSizer(vbox)
        
    def OnEnter(self,event):
        self.OnOk(event)
        
    def OnOk(self,event):
        if self.sensortxt.GetValue() == "":
            wx.MessageBox('No sensors!','Alert')
        elif self.addrtxt.GetValue() == "":
            wx.MessageBox('No address!','Alert')
        else:
            self.parent.donothing = False
            self.parent.phys.SetLabel(self.addrtxt.GetValue())
            self.parent.initsensors.SetLabel(self.sensortxt.GetValue())
            self.Close()
            
    def OnClose(self,event):
        self.Close()
        
class trainPanel(wx.Panel):
    def __init__(self, parent, id, number):
        super(trainPanel, self).__init__(parent, id, style=wx.RAISED_BORDER)
        self.parent = parent
        self.number = number
        self.steal = False
        self.slot = -1
        self.virslot = -1
        self.connected = False
        self.donothing = False
        box = wx.BoxSizer(wx.HORIZONTAL)
        self.speed =  wx.Slider(self,id,0,0,127,pos=(-1,-1),style=wx.SL_VERTICAL|wx.SL_LABELS|wx.SL_INVERSE)
        self.speed.Disable()
        self.Bind(wx.EVT_COMMAND_SCROLL_CHANGED, self.OnSpeed, self.speed)
        box.Add(self.speed,0)
        
        #first column of buttons: Reverse, Lights, Mute, Select!, Steal!
        togglecol = wx.BoxSizer(wx.VERTICAL)
        self.dir = wx.ToggleButton(self,id,"Reverse")
        self.dir.Disable()
        self.Bind(wx.EVT_TOGGLEBUTTON, self.OnDirf, self.dir)
        togglecol.Add(self.dir,0)
        self.lights = wx.ToggleButton(self,id,"Lights")
        self.lights.Disable()
        self.Bind(wx.EVT_TOGGLEBUTTON, self.OnDirf, self.lights)
        togglecol.Add(self.lights,0)
        self.mute = wx.ToggleButton(self,id,"Mute")
        self.mute.Disable()
        self.Bind(wx.EVT_TOGGLEBUTTON, self.OnMute, self.mute)
        togglecol.Add(self.mute,0)
        self.select = wx.Button(self,id,"Select")
        self.Bind(wx.EVT_BUTTON, self.OnRegister, self.select)
        togglecol.Add(self.select,0)
        self.steal = wx.Button(self,id,"Steal")
        self.Bind(wx.EVT_BUTTON, self.OnRegister, self.steal)
        togglecol.Add(self.steal,0)
        box.Add(togglecol,0)
        
        #second column of buttons: Horn, Bell, (blank), state, init
        soundcol = wx.BoxSizer(wx.VERTICAL)
        self.horn = wx.ToggleButton(self,id,"Horn")
        self.horn.Disable()
        self.Bind(wx.EVT_TOGGLEBUTTON, self.OnDirf, self.horn)
        soundcol.Add(self.horn,0)
        self.bell = wx.ToggleButton(self,id,"Bell")
        self.bell.Disable()
        self.Bind(wx.EVT_TOGGLEBUTTON, self.OnDirf, self.bell)
        soundcol.Add(self.bell,0)
        soundcol.Add(wx.StaticText(self,id,"",size=self.bell.GetSize()),0)
        self.state = wx.StaticText(self,id,"?",size=self.bell.GetSize())
        soundcol.Add(self.state,0)
        self.doinit = wx.Button(self,id,"Init")
        self.Bind(wx.EVT_BUTTON, self.OnInit, self.doinit)
        soundcol.Add(self.doinit,0)
        
        box.Add(soundcol,0)
        
        #third column of labeles with boxes: Train(phys slot), PhyAdr, VirAdr, VirSlot, SensorList
        infocol = wx.BoxSizer(wx.VERTICAL)
        namerow = wx.BoxSizer(wx.HORIZONTAL)
        self.namelabel = wx.StaticText(self,id,"PhySlot: ",size=(-1,self.horn.GetSize()[1]))
        self.name = wx.StaticText(self,id,"")
        namerow.Add(self.namelabel,0)
        namerow.Add(self.name,0,wx.ALIGN_RIGHT)
        infocol.Add(namerow,0)
        physrow = wx.BoxSizer(wx.HORIZONTAL)
        self.physlabel = wx.StaticText(self,id,"PhyAdr: ",size=(-1,self.horn.GetSize()[1]))
        self.phys = wx.StaticText(self,id,"")
        physrow.Add(self.physlabel,0)
        physrow.Add(self.phys,0,wx.ALIGN_RIGHT)
        infocol.Add(physrow,0)
        virrow = wx.BoxSizer(wx.HORIZONTAL)
        self.virlabel = wx.StaticText(self,id,"VirAdr: ",size=(-1,self.horn.GetSize()[1]))
        self.vir = wx.StaticText(self,id,"")
        virrow.Add(self.virlabel,0)
        virrow.Add(self.vir,0,wx.ALIGN_RIGHT)
        infocol.Add(virrow,0)
        virslotrow = wx.BoxSizer(wx.HORIZONTAL)
        self.virslotlabel = wx.StaticText(self,id,"VirSlot: ",size=(-1,self.horn.GetSize()[1]))
        self.virslottext = wx.StaticText(self,id,"")
        virslotrow.Add(self.virslotlabel,0)
        virslotrow.Add(self.virslottext,0,wx.ALIGN_RIGHT)
        infocol.Add(virslotrow,0)
        initrow = wx.BoxSizer(wx.HORIZONTAL)
        self.initlabel = wx.StaticText(self,id,"Sensors: ",size=(-1,self.horn.GetSize()[1]))
        self.initsensors = wx.StaticText(self,id,"",size=(self.horn.GetSize()[0]*2,-1))
        initrow.Add(self.initlabel,0)
        initrow.Add(self.initsensors,0,wx.ALIGN_RIGHT)
        infocol.Add(initrow,0)
        box.Add(infocol,0)
        
        self.SetSizer(box)
        
    def OnSpeed(self,event):
        slider = event.GetEventObject()
        msg = OPC_LOCO_SPD('10100000', self.slot, slider.GetValue())
        logmsg = 'Set train #' + repr(self.number) + ' speed to ' + repr(slider.GetValue())
        cmd = LocoLib.changeSpeed(msg)
        self.parent.SendCmd(cmd)
        self.parent.log.SetValue(logmsg + '\n' + self.parent.log.GetValue())
        self.Refresh()
        
    def OnDirf(self,event):
        toggle = event.GetEventObject()
        onoff = self.mute.GetValue()
        dir = 0
        if trains[self.number].dir.GetValue(): 
            dir = 1 
        light = 0
        if trains[self.number].lights.GetValue(): 
            light = 1
        horn = 0
        if trains[self.number].horn.GetValue() and not onoff: 
            horn = 1
        bell = 0
        if trains[self.number].bell.GetValue() and not onoff: 
            bell = 1
        msg = OPC_LOCO_DIRF('OPC_LOCO_DIRF', self.slot, dir, light, 
                            horn, bell)
        cmd = LocoLib.changeDirf(msg)
        label = toggle.GetLabel()
        logmsg = 'Set train #' + repr(self.number) + ' ' + label + ' to ' + repr(toggle.GetValue())
        self.parent.SendCmd(cmd)
        self.parent.log.SetValue(logmsg + '\n' + self.parent.log.GetValue())
        self.Refresh()
        
    def OnMute(self,event):
        toggle = event.GetEventObject()
        onoff = toggle.GetValue()
        dir = 0
        if trains[self.number].dir.GetValue(): 
            dir = 1 
        light = 0
        if trains[self.number].lights.GetValue(): 
            light = 1
        horn = 0
        if trains[self.number].horn.GetValue() and not onoff: 
            horn = 1
        bell = 0
        if trains[self.number].bell.GetValue() and not onoff: 
            bell = 0
        mute = 0
        if trains[self.number].mute.GetValue():
            mute = 1
        cmd = LocoLib.changeSnd(OPC_LOCO_SND('1',self.slot,repr(mute)))
        logmsg = 'Set train #' + repr(self.number) + ' mute to ' + repr(toggle.GetValue())
        self.parent.SendCmd(cmd)
        self.parent.log.SetValue(logmsg + '\n' + self.parent.log.GetValue())
        self.Refresh()
        
    def OnRegister(self,event):
        button = event.GetEventObject()
        dlg = registerBox(self)
        dlg.ShowModal()
        dlg.Destroy()
        if self.donothing == False:
            toconnect = self.phys.GetLabel()
            if toconnect == "":
                temp = 'select'
                if button.GetLabel() == 'Steal':
                    temp = 'steal'
                wx.MessageBox('No address to ' + temp, 'Alert')
            self.parent.regtrain = self.number
            if button.GetLabel() == 'Steal':
                cmd = self.parent.TranslateCmd('ST ' + toconnect)
            else:
                cmd = self.parent.TranslateCmd('SE ' + toconnect)
            self.parent.SendCmd(cmd)
            self.donothing = True
        self.Refresh()
        
    def OnInit(self,event):
        dlg = initBox(self)
        dlg.ShowModal()
        dlg.Destroy()
        if self.donothing == False:
            sensorstringlist = self.initsensors.GetLabel().split(",")
            sensorlist = []
            for sensor in sensorstringlist:
                if sensor == "":
                    wx.MessageBox('No sensorlist!', 'Alert')
                    return
                temp = eval(sensor.strip())
                sensorlist.append(temp)
            if self.phys.GetLabel() == "":
                wx.MessageBox('No physical address!', 'Alert')
                return
            addr = eval(self.phys.GetLabel())
            self.parent.initaddr = addr
            self.parent.inittrain = self.number
            count = len(sensorlist)
            cmd = LocoLib.doLocoInit(DO_LOCO_INIT('1',addr,count,sensorlist))
            logmsg = 'Initializing train #' + repr(self.number) + ' at ' + repr(addr) + ' to: ' + repr(sensorlist)
            self.parent.SendCmd(cmd)
            self.parent.log.SetValue(logmsg + '\n' + self.parent.log.GetValue())
            self.donothing = True
        self.Refresh()
        
class switchPanel(wx.Panel):
    def __init__(self, parent, id):
        self.parent = parent
        super(switchPanel, self).__init__(parent, id, style=wx.RAISED_BORDER)
        box = wx.BoxSizer(wx.VERTICAL)
        cols = 4
        rows = 11
        gs = wx.GridSizer(cols,rows,0,0)
        self.grid = {}
        for i in range(1,(cols-1)*(rows-1)):
            self.grid[i] = wx.ToggleButton(self,i,'?',size=(20,-1))
            self.Bind(wx.EVT_TOGGLEBUTTON, self.OnSwitch, self.grid[i])
                
        for i in range(-1,cols-1):
            for j in range(-1,rows-1):
                if (i == -1 and j == -1) or (i == 0 and j == 0):
                    gs.Add(wx.StaticText(self,-1,''),0,wx.EXPAND) #empty corners
                elif i == -1 and j > -1:
                    gs.Add(wx.StaticText(self,-1,repr(j)),0,wx.EXPAND) #first row
                elif i > -1 and j == -1:
                    gs.Add(wx.StaticText(self,-1,repr(i)),0,wx.EXPAND) #first column
                else:
                    spot = int(repr(i) + repr(j))
                    gs.Add(self.grid[spot],0,wx.EXPAND)
                    
        box.Add(gs,0,wx.EXPAND)
        
        self.SetSizer(box)
        
    def OnSwitch(self,event):
        switch = event.GetEventObject()
        if switch.GetLabel() == '?':
            switch.SetLabel(repr(switch.GetId()))
        if switch.GetValue():
            cmd = self.parent.TranslateCmd('C ' + repr(switch.GetId()))
        else:
            cmd = self.parent.TranslateCmd('T ' + repr(switch.GetId()))
        switch.SetValue(not switch.GetValue())
        self.parent.SendCmd(cmd)
        self.Refresh()
        
class globalPanel(wx.Panel):
    def __init__(self, parent, id):
        super(globalPanel, self).__init__(parent, id, style=wx.RAISED_BORDER)
        
        self.parent = parent
        self.scriptThread = None
        self.runningscript = False
        self.scriptLock = thread.allocate_lock()
        
        box = wx.BoxSizer(wx.HORIZONTAL)
        self.haltall = wx.Button(self,id,"Halt All")
        self.Bind(wx.EVT_BUTTON, self.OnHalt, self.haltall)
        box.Add(self.haltall,0)
        self.readxml = wx.Button(self,id,"Read XML")
        self.xmlfile = ''
        self.Bind(wx.EVT_BUTTON, self.OnReadXML, self.readxml)
        box.Add(self.readxml,0)
        col = wx.BoxSizer(wx.VERTICAL)
        self.loadscript = wx.Button(self,id,"Load Script")
        self.scriptfile = ''
        self.Bind(wx.EVT_BUTTON, self.OnLoadScript, self.loadscript)
        col.Add(self.loadscript,0)
        self.stopscript = wx.Button(self,id,"Stop Script")
        self.Bind(wx.EVT_BUTTON, self.OnStopScript, self.stopscript)
        col.Add(self.stopscript,0)
        box.Add(col,0)
        
        self.SetSizer(box)
        
    def OnHalt(self,event):
        for i in trains:
            if trains[i].connected == True:
                msg = OPC_LOCO_SPD('10100000', trains[i].slot, 0)
                trains[i].speed.SetValue(0)
                cmd = LocoLib.changeSpeed(msg)
                self.parent.SendCmd(cmd)
        logmsg = 'Halted all trains'
        self.parent.log.SetValue(logmsg + '\n' + self.parent.log.GetValue())
        self.Refresh()
    
    def OnReadXML(self,event):
        filter = "All files (*.*)|*.*|XML Files (*.xml)|*.xml"
        dialog = wx.FileDialog(self,"Read XML",
                               wildcard=filter,style=wx.FD_OPEN)
        dialog.SetFilename(self.xmlfile)
        if dialog.ShowModal() == wx.ID_OK:
            self.xmlfile = dialog.GetFilename()
        dialog.Destroy()
        
    def OnLoadScript(self,event):
        filter = "All files (*.*)|*.*|Text Files (*.txt)|*.txt"
        dialog = wx.FileDialog(self,"Load Script",defaultFile=self.scriptfile,
                               wildcard=filter,style=wx.FD_OPEN)
        dialog.SetFilename(self.scriptfile)
        gotscript = False
        if dialog.ShowModal() == wx.ID_OK:
            try:
                self.scriptfile = dialog.GetPath()
                f = open(self.scriptfile)
                script = f.readlines()
                f.close()
                gotscript = True
            except:
                wx.MessageBox('Bad Filename!', 'Alert')
        dialog.Destroy()
        if gotscript:
            self.tempThread = threading.Thread(target=self.DoScript,args=(script,))
            self.tempThread.start()
            self.runningscript = True
            
    def OnStopScript(self,event):
        if self.runningscript:
            self.scriptLock.acquire()
            self.runningscript = False
            self.scriptLock.release()
        
    def DoScript(self,script):
        waitfor = 0
        for line in script:
            self.scriptLock.acquire()
            words = line.split()
            scr_time = eval(words[0])
            cmd = ''
            for i in range(1,len(words)):
                cmd += words[i] + ' '
            #cmd = words[1] + ' ' + words[2]
            waitfor = scr_time-waitfor
            self.scriptLock.release()
            time.sleep(waitfor)
            waitfor = scr_time
            if self.runningscript == False:
                return
            self.scriptLock.acquire()
            self.parent.fromcmdline = True
            tosend = self.parent.TranslateCmd(cmd)
            self.parent.SendCmd(tosend)
            self.Refresh()
            self.scriptLock.release()

class sectionPanel(wx.Panel):
    def __init__(self, parent, id):
        self.parent = parent
        super(sectionPanel, self).__init__(parent, id, style=wx.RAISED_BORDER)
        box = wx.BoxSizer(wx.VERTICAL)
        cols = 11
        rows = 13
        gs = wx.GridSizer(rows,cols,0,0)
        self.grid = {}
        for i in range(0,rows-1):
            for j in range(0,cols-1):
                self.grid[i,j] = wx.StaticText(self,i,'-',size=(20,-1))
                
        for i in range(-1,rows-1): #cols
            for j in range(-1,cols-1): #rows
                if i == -1 and j == -1:
                    gs.Add(wx.StaticText(self,-1,''),0,wx.EXPAND) #empty corner
                elif i == -1 and j > -1:
                    gs.Add(wx.StaticText(self,-1,repr(j)),0,wx.EXPAND) #first row
                elif i > -1 and j == -1:
                    gs.Add(wx.StaticText(self,-1,repr(i)),0,wx.EXPAND) #first column
                else:
                    spot = int(repr(i) + repr(j))
                    gs.Add(self.grid[i,j],0,wx.EXPAND)
                    
        box.Add(gs,0,wx.EXPAND)
        
        self.SetSizer(box)

class logoPanel(wx.Panel):
    def __init__(self, parent, id, size):
        super(logoPanel, self).__init__(parent, id, size, style=wx.RAISED_BORDER)
        self.parent = parent
        self.size = size
        self.Bind(wx.EVT_PAINT, self.OnPaint)
        self.logo = wx.Image(name = "resources/logo.png").Rescale(width = self.size[0],height = self.size[1]).ConvertToBitmap()
        
    def OnPaint(self, event):
        dc = wx.PaintDC(self)
        #dc.Clear()
        dc.DrawBitmap(self.logo,1,30,False)
        #self.Refresh()
       
#Panel that holds rows of wx widgets.
class myPanel(wx.Panel):
    def __init__(self, parent, id):
        super(myPanel, self).__init__(parent, id)
        size = parent.size
        self.parent = parent
        self.regstate = 'None'
        self.regtrain = 0
        self.initaddr = 0
        self.inittrain = 0
        self.freetrains = []
        self.fromcmdline = False
        w,h = size
        colsize = w/10
        rowsize = h/18
        
        #bring up initial connection box. Same one can be found in menu.
        if not sets.connected:
            dlg = connectBox(self,sets.soc)
            dlg.ShowModal()
            dlg.Destroy()
        
        #initialize LocoTransmitter
        if not sets.lt:
            sets.lt = LocoTransmitter(sets.soc)
            
        #start reading
        self.readerThread = threading.Thread(target=self.Reader)
        self.readerThread.start()
        
        #log box
        vbox = wx.BoxSizer(wx.VERTICAL)
        self.log = wx.TextCtrl(self,id,size=(w,h/5),style=wx.TE_MULTILINE|wx.TE_READONLY)
        vbox.Add(self.log,0)
        
        therest = wx.BoxSizer(wx.HORIZONTAL)
        
       #left side, switches and global controls.
        switchcol = wx.BoxSizer(wx.VERTICAL)
        self.switches = switchPanel(self, -1)
        switchcol.Add(self.switches,0)
        self.globalcontrols = globalPanel(self, -1)
        switchcol.Add(self.globalcontrols,0)
        self.sections = sectionPanel(self, -1)
        switchcol.Add(self.sections,0)
        self.logo = logoPanel(self,-1,(215,116))
        switchcol.Add(self.logo,1,wx.EXPAND)
        therest.Add(switchcol,1,wx.EXPAND)
        self.logo.Refresh()
        
        #right side, trains[1..4]
        trainscol = wx.BoxSizer(wx.VERTICAL)
        for i in range(1,5):
            trains[i] = trainPanel(self, -1, i)
            trainscol.Add(trains[i],0)
            self.freetrains.append(i)
        trains[1].phys.SetLabel('1111')             #comment out to remove default setting
        trains[1].initsensors.SetLabel('255,251')
        trains[2].phys.SetLabel('2222')
        trains[2].initsensors.SetLabel('256,252')
        trains[3].phys.SetLabel('3333')
        trains[3].initsensors.SetLabel('257,253')
        trains[4].phys.SetLabel('4444')
        trains[4].initsensors.SetLabel('258,254')
        therest.Add(trainscol,0)
        
        vbox.Add(therest,0)

        row10 = wx.BoxSizer(wx.HORIZONTAL)
        self.inputtxt = wx.TextCtrl(self, id, "some command goes here", 
                                    style=wx.TE_PROCESS_ENTER,
                                    pos=(0*colsize+40,16*rowsize),size=(w-50,-1))

        self.Bind(wx.EVT_TEXT_ENTER,self.OnEnter,self.inputtxt)
        row10.Add(self.inputtxt,0)
        vbox.Add(row10,0)
        
        self.SetSizer(vbox)
        
    #Reader reads a message and decides what to do with it based on the opcode.
    #
    #
    def Reader(self):
        while True:
            msg = LocoLib.convertToStandardMessage(sets.lt.readMsg())
            logmsg = ''
            if msg.command == 'OPC_SL_RD_DATA':
                slot = msg.slot
                addr = msg.adr
                train = trains[self.regtrain]
                if self.regstate == 'Select':   
                    if msg.status == '11':
                        logmsg = 'already a connection at ' + repr(addr)
                    else:
                        train.name.SetLabel(repr(slot))
                        train.slot = slot
                        tosend = LocoLib.moveSlots(OPC_MOVE_SLOTS('1',slot,slot))
                        sets.lt.send(tosend)
                        tosend = LocoLib.changeSpeed(OPC_LOCO_SPD('1',slot,train.speed.GetValue()))
                        sets.lt.send(tosend)
                        if train.dir.GetValue():
                            dir = 1
                        else:
                            dir = 0
                        if train.lights.GetValue():
                            lights = 1
                        else:
                            lights = 0
                        if train.horn.GetValue():
                            horn = 1
                        else:
                            horn = 0
                        if train.bell.GetValue():
                            bell = 1
                        else:
                            bell = 0
                        tosend = LocoLib.changeDirf(OPC_LOCO_DIRF('1',slot,dir,
                                               lights,
                                               horn,
                                               bell))
                        sets.lt.send(tosend)
                        train.phys.SetLabel(repr(addr))
                        train.speed.Enable(True)
                        train.dir.Enable(True)
                        train.lights.Enable(True)
                        train.mute.Enable(True)
                        train.horn.Enable(True)
                        train.bell.Enable(True)
                        train.connected = True
                        logmsg = 'registered to ' + repr(slot)
                        try:
                            self.freetrains.remove(self.regtrain)
                        except:
                            None
                elif self.regstate == 'Steal':
                    if msg.status == '11':
                        logmsg = 'stolen from ' + repr(addr)
                        train.name.SetLabel(repr(slot))
                        train.slot = slot
                        train.phys.SetLabel(repr(addr))
                        train.speed.Enable(True)
                        train.dir.Enable(True)
                        train.lights.Enable(True)
                        train.mute.Enable(True)
                        train.horn.Enable(True)
                        train.bell.Enable(True)
                        train.connected = True
                        try:
                            self.freetrains.remove(self.regtrain)
                        except:
                            None
                    else:
                        logmsg = 'Steal failed from ' + repr(addr)
                self.regstate = 'None'
            elif msg.command == 'OPC_SW_REP':
                state = ''
                if msg.hl == '1':
                    state = 'closed.'
                    self.switches.grid[msg.switchNum].SetValue(True)
                    self.switches.grid[msg.switchNum].SetLabel(repr(msg.switchNum))
                else:
                    state = 'open.'
                    self.switches.grid[msg.switchNum].SetValue(False)
                    self.switches.grid[msg.switchNum].SetLabel(repr(msg.switchNum))
                logmsg = 'Toggled switch ' + repr(msg.switchNum) + ' ' + state
            elif msg.command == 'OPC_INPUT_REP':
                logmsg = 'Sensor ' + str(msg.sensor) + ' fired ' + str(msg.hl)
            elif msg.command == 'PUT_INIT_OUTCOME':
                if msg.pAdr == self.initaddr:
                    self.initaddr = -1
                    train = trains[self.inittrain]
                    train.phys.SetLabel(repr(msg.pAdr))
                    train.name.SetLabel(repr(msg.pSlot))
                    train.slot = msg.vSlot
                    train.virslot = msg.vSlot
                    train.vir.SetLabel(repr(msg.vAdr))
                    train.virslottext.SetLabel(repr(msg.vSlot))
                    train.speed.Enable(True)
                    train.dir.Enable(True)
                    train.lights.Enable(True)
                    train.mute.Enable(True)
                    train.horn.Enable(True)
                    train.bell.Enable(True)
                    train.connected = True
                    logmsg = 'Initialized train #' + repr(self.inittrain) + ' at ' + repr(msg.pAdr) + ' to slot ' + repr(msg.vSlot)
                    try:
                        self.freetrains.remove(self.regtrain)
                    except:
                        None
            elif msg.command == 'PUT_TRAIN_STATE':
                slot = msg.slot
                train = None
                for t in trains.values():
                    if t.slot == slot:
                        train = t
                if train is not None:
                    if msg.state == 0:
                        state = 'MOVE'
                    elif msg.state == 1:
                        state = 'WAIT'
                    elif msg.state == 2:
                        state = 'HALT'
                    elif msg.state == 3:
                        state = 'ERROR'
                    elif msg.state == 4:
                        state = 'BEGIN CHANGE'
                    elif msg.state == 5:
                        state = 'BEGIN WAIT'
                    elif msg.state == 6:
                        state = 'BEGIN HALT'
                    train.state.SetLabel(state)
                    logmsg = 'Put train ' + repr(slot) + ' state to ' + state
            elif msg.command == 'PUT_TRAIN_POSITION':
                slot = msg.slot
                train = None
                for t in trains.values():
                    if t.slot == slot:
                        train = t
                if train is not None:
                    sensorList = msg.sensorList
                    mystr = ''
                    for s in sensorList:
                        mystr += repr(s) + ','
                    mystr = mystr.rstrip(',')
                    train.initsensors.SetLabel(mystr)
                    logmsg = 'Put train ' + repr(slot) + ' position to ' + mystr
            elif msg.command == 'PUT_SECTION_STATE':
                section = msg.section
                if msg.state == 0:
                    state = 'F'
                elif msg.state == 1:
                    state = 'R'
                elif msg.state == 2:
                    state = 'O'
                elif msg.state == 3:
                    state = 'B'
                if section < 119:
                    row = section/10
                    col = section%10
                    spot = row,col
                    self.sections.grid[spot].SetLabel(state)
                logmsg = 'Put section ' + repr(section) + ' state to ' + state
            elif msg.command == 'PUT_SWITCH_STATE':
                switch = msg.switch
                state = None
                if msg.state == 0:
                    state = True
                    st = 'closed'
                elif msg.state == 1:
                    state = False
                    st = 'open'
                elif msg.state == 2:
                    st = 'begin closed'
                    self.switches.grid[switch].SetLabel('>')
                elif msg.state == 3:
                    st = 'begin thrown'
                    self.switches.grid[switch].SetLabel('<')
                else:
                    st = 'unknown'
                    self.switches.grid[switch].SetLabel('?')
                if state is not None:
                    self.switches.grid[switch].SetLabel(repr(switch))
                    self.switches.grid[switch].SetValue(state)
                logmsg = 'Put switch ' + repr(switch) + ' state to ' + st
            elif msg.command.count('MSG_') > 0:
                None
            else:
                logmsg = 'ack. nothing to do'
            self.log.SetValue(logmsg + '\n' + self.log.GetValue())

    #translates what is in the self.inputtxt field to a command if possible and returns
    # the command to be sent via tcp/ip.
    def TranslateCmd(self, rawinput):
        logmsg = ''
        words = rawinput.split()
        if len(words) > 1 or words[0] == '.':
            cmd = string.upper(words[0])
            if cmd == 'SE':
                self.regstate = 'Select'
                if len(self.freetrains) > 0 and self.fromcmdline:
                    self.regtrain = self.freetrains.pop(0)
                    self.fromcmdline = False
                msg = OPC_LOCO_ADR('1',eval(words[1]))
                return LocoLib.locoAdr(msg)
            elif cmd == 'ST':
                self.regstate = 'Steal'
                if len(self.freetrains) > 0 and self.fromcmdline:
                    self.regtrain = self.freetrains.pop(0)
                    self.fromcmdline = False
                msg = OPC_LOCO_ADR('1',eval(words[1]))
                return LocoLib.locoAdr(msg)
            elif cmd == '.':
                self.globalcontrols.OnHalt(None)
                return 'HALTALL'
            elif cmd == 'Z':
                addr = eval(words[1])
                count = eval(words[2])
                sensorlist = []
                for i in range(3,len(words)):
                    sensorlist.append(eval(words[i]))
                msg = DO_LOCO_INIT('DO_LOCO_INIT',addr,count,sensorlist)
                return LocoLib.doLocoInit(msg)
            elif cmd == 'T':
                msg = OPC_SW_REQ('10110000', eval(words[1]), '1', '0')
                return LocoLib.moveTurnout(msg)
                #return 'throw' + ' ' + words[1]
            elif cmd == 'C':
                msg = OPC_SW_REQ('10110000', eval(words[1]), '1', '1')
                return LocoLib.moveTurnout(msg)
                #return 'close' + ' ' + words[1]
            elif cmd == 'I':
                slot = eval(words[1])
                train = trains[slot]
                slot = train.slot
                speed = train.speed.GetValue()
                if speed + 10 > 127:
                    train.speed.SetValue(127)
                else:
                    train.speed.SetValue(speed + 10)
                speed = train.speed.GetValue()
                msg = OPC_LOCO_SPD('10100000', slot, speed)
                return LocoLib.changeSpeed(msg)
            elif cmd == 'D':
                slot = eval(words[1])
                train = trains[slot]
                slot = train.slot
                speed = train.speed.GetValue()
                if speed - 10 < 0:
                    train.speed.SetValue(0)
                else:
                    train.speed.SetValue(speed - 10)
                speed = train.speed.GetValue()
                msg = OPC_LOCO_SPD('10100000', slot, speed)
                return LocoLib.changeSpeed(msg)
            elif cmd == 'F':
                slot = eval(words[1])
                train = trains[slot]
                slot = train.slot
                dir = 0
                train.dir.SetValue(False)
                if train.lights.GetValue():
                    lights = 1
                else:
                    lights = 0
                if train.horn.GetValue():
                    horn = 1
                else:
                    horn = 0
                if train.bell.GetValue():
                    bell = 1
                else:
                    bell = 0
                msg = OPC_LOCO_DIRF('10100001', slot, dir, lights, horn, bell)
                return LocoLib.changeDirf(msg)
            elif cmd == 'B':
                slot = eval(words[1])
                train = trains[slot]
                slot = train.slot
                dir = 1
                train.dir.SetValue(True)
                if train.lights.GetValue():
                    lights = 1
                else:
                    lights = 0
                if train.horn.GetValue():
                    horn = 1
                else:
                    horn = 0
                if train.bell.GetValue():
                    bell = 1
                else:
                    bell = 0
                msg = OPC_LOCO_DIRF('10100001', slot, dir, lights, horn, bell)
                return LocoLib.changeDirf(msg)
            elif cmd == 'L':
                slot = eval(words[1])
                train = trains[slot]
                slot = train.slot
                if train.dir.GetValue():
                    dir = 1
                else:
                    dir = 0
                if train.lights.GetValue():
                    lights = 0
                    train.lights.SetValue(False)
                else:
                    lights = 1
                    train.lights.SetValue(True)
                if train.horn.GetValue():
                    horn = 1
                else:
                    horn = 0
                if train.bell.GetValue():
                    bell = 1
                else:
                    bell = 0
                msg = OPC_LOCO_DIRF('10100001', slot, dir, lights, horn, bell)
                return LocoLib.changeDirf(msg)
            elif cmd == 'H':
                slot = eval(words[1])
                train = trains[slot]
                slot = train.slot
                if train.dir.GetValue():
                    dir = 1
                else:
                    dir = 0
                if train.lights.GetValue():
                    lights = 1
                else:
                    lights = 0
                if train.horn.GetValue():
                    horn = 0
                    train.horn.SetValue(False)
                else:
                    horn = 1
                    train.horn.SetValue(True)
                if train.bell.GetValue():
                    bell = 1
                else:
                    bell = 0
                msg = OPC_LOCO_DIRF('10100001', slot, dir, lights, horn, bell)
                return LocoLib.changeDirf(msg)
            elif cmd == 'E':
                slot = eval(words[1])
                train = trains[slot]
                slot = train.slot
                if train.dir.GetValue():
                    dir = 1
                else:
                    dir = 0
                if train.lights.GetValue():
                    lights = 1
                else:
                    lights = 0
                if train.horn.GetValue():
                    horn = 1
                else:
                    horn = 0
                if train.bell.GetValue():
                    bell = 0
                    train.bell.SetValue(False)
                else:
                    bell = 1
                    train.bell.SetValue(True)
                msg = OPC_LOCO_DIRF('10100001', slot, dir, lights, horn, bell)
                return LocoLib.changeDirf(msg)
            elif cmd == 'M':
                slot = eval(words[1])
                train = trains[slot]
                slot = train.slot
                if train.mute.GetValue():
                    mute = 0
                    train.mute.SetValue(False)
                else:
                    mute = 1
                    train.mute.SetValue(True)
                msg = OPC_LOCO_SND('10100010', slot, repr(mute))
                return LocoLib.changeSnd(msg)
            else:
                return 'not a command'
        else:
            return 'not a command'

    #needs to send the translated command to the socket.
    def SendCmd(self, cmd):
        if sets.connected:
            sets.lt.send(cmd)
        
    def OnEnter(self,event):
        self.fromcmdline = True
        cmd = self.TranslateCmd(self.inputtxt.GetValue())
        self.SendCmd(cmd)
        self.Refresh()
            
if __name__ == "__main__":
    app = wx.App()
    frame = myFrame(None, -1)
    frame.Show()
    app.MainLoop()
