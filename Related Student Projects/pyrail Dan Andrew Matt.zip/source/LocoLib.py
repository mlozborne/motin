### PyRail Project - Loconet Library
### Authors: Matthew Preucil, Andrew Larsen (add if you edit)
### Description: Library for all objects and methods that  communicate  with
###              the LocoBufferServer, parse, and translate loconet messages


import threading
import socket
import sys
from collections import deque

from helpers import helpers as h
from collections import namedtuple
import doctest

OPC_SW_REQ = namedtuple('OPC_SW_REQ', ['command', 'switchNum', 'output', 'dir']) # Turnout set message: dir = 1 for closed, output 1 for confirmation message
OPC_LOCO_SPD = namedtuple('OPC_LOCO_SPD', ['command', 'slot', 'speed']) # Set speed msg
OPC_LOCO_DIRF = namedtuple('OPC_LOCO_DIRF',['command', 'slot', 'dir', 'lights', 'horn', 'bell'])
OPC_LOCO_SND = namedtuple('OPC_LOCO_SND', ['command', 'slot', 'mute'])
OPC_INPUT_REP = namedtuple('OPC_INPUT_REP', ['command', 'sensor', 'hl'])
OPC_SW_REP = namedtuple('OPC_SW_REP', ['command', 'switchNum', 'hl'])
OPC_MOVE_SLOTS = namedtuple('OPC_MOVE_SLOTS', ['command', 'slotSrc', 'slotDst'])
OPC_LOCO_ADR = namedtuple('OPC_LOCO_ADR', ['command', 'locoAdr'])
OPC_LONG_ACK = namedtuple('OPC_LONG_ACK', ['command', 'lopc'])
OPC_SL_RD_DATA = namedtuple('OPC_SL_RD_DATA', ['command', 'slot', 'status', 'adr', 'hexStr'])

# His added messages:

DO_LOCO_INIT = namedtuple('DO_LOCO_INIT', ['command', 'pLocoAdr', 'count', 'sensorList'])
PUT_INIT_OUTCOME = namedtuple('PUT_INIT_OUTCOME', ['command', 'pAdr', 'pSlot', 'vAdr', 'vSlot'])
PUT_TRAIN_STATE = namedtuple('PUT_TRAIN_STATE', ['command', 'slot', 'state'])
PUT_TRAIN_POSITION = namedtuple('PUT_TRAIN_POSITION', ['command', 'slot', 'sensorList'])
PUT_SECTION_STATE = namedtuple('PUT_SECTION_STATE', ['command', 'section', 'state'])
PUT_SWITCH_STATE = namedtuple('PUT_SWITCH_STATE', ['command', 'switch', 'state'])
PUT_SENSOR_STATE = namedtuple('PUT_SENSOR_STATE', ['command', 'sensor', 'state'])
MSG_TRY_MOVE_AGAIN = namedtuple('MSG_TRY_MOVE_AGAIN', ['command'])
MSG_FRONT_SENSOR_FIRED = namedtuple('MSG_FRONT_SENSOR_FIRED', ['command', 'trainId'])
MSG_BACK_SENSOR_FIRED = namedtuple('MSG_BACK_SENSOR_FIRED', ['command', 'trainId'])
MSG_SENSOR_ERROR = namedtuple('MSG_SENSOR_ERROR', ['command', 'sensor'])
MSG_LOSE_RESERVATION = namedtuple('MSG_LOSE_RESERVATION', ['command', 'trainId'])
PUT_TRAIN_INFORMATION = namedtuple('PUT_TRAIN_INFORMATION', ['command', 'slot', 'speed', 'dir', 'light', 'bell', 'horn', 'mute'])
GET_SWITCH_STATES = namedtuple('GET_SWITCH_STATES', ['command'])

# Note implemented yet:

# Probably won't do (until the whole thing works):
#  GET_SWITCH_SUCESSOR -6
#  PUT_SWITCH_SUCCESSOR -7
#  DO_READ_LAYOUT -10 # in pyrail for now
#  PUT_READ_LAYOUT_RESPONSE -11 # in pyrail for now

### Class: LocoStream
### Purpose: The LocoStream encapsulates  a byte  stream and methods to  retrieve
###          complete Loco Messages out of it.
### WARNING: This class is not thread-safe and should ONLY by used by  an  object
###          that provides thread-safe access to it, such as the LocoTransmitter.

class LocoStream:

    def __init__(self):
        self.stream = deque()

    def addBytes(self, bytes):
        self.stream.append(bytes)

    def parseLocoMsg(self):
        msg = None
        try:
            msg = self.stream.popleft()
        except:
            return None
        return msg

### Class: LocoTransmitter
### Purpose: The LocoTransmitter encapsulates communication  with a TCP server.
###          Once instantiated, readMsg is a blocking  function  that returns a
###          complete Loco Message.

class LocoTransmitter:

    def __init__(self, socket):
        self.stream = LocoStream()       # Holds incoming data and parses complete messages
        self.socket = socket             # socket
        self.cv = threading.Condition()  # Condition variable for message buffer
        self.alive = True
        self.connected = True
        self.readerThread = threading.Thread(target=self.socketReader)
        self.readerThread.start()
        self._write_lock = threading.Lock()

### Function: readMsg
### Purpose: Does a blocking read until a complete Loco Message can be read.

    def readMsg(self):
        self.cv.acquire()
        msg = self.stream.parseLocoMsg()
        while msg is None and self.alive:
            self.cv.wait()
            msg = self.stream.parseLocoMsg()
        self.cv.release()
        return msg

### Function: socketReader
### Purpose: Reads from the socket and adds bytes to the stream

    def socketReader(self):
        self.socket.settimeout(1)
        while self.alive:
            try:
                data = self.socket.recv(2)
                if data is not None and len(data) > 0:
                    num = ord(data[0])
                    stuff = self.socket.recv(num)
                    if stuff is not None:
                        data += stuff
                else:
                    data = None
            except socket.timeout:
                data = None
            except Exception as inst:
                sys.stderr.write("Error: %s" % inst)
                self.socket.close()
                self.alive = False
                break
            if data is not None:
                self.cv.acquire()
                self.stream.addBytes(data)
                self.cv.notifyAll()
                self.cv.release()
        self.socket.shutdown(socket.SHUT_RDWR)
        self.socket.close()
        # Signal anyone waiting on a msg
        self.cv.acquire()
        self.connected = False
        self.cv.notifyAll()
        self.cv.release()

### Function: send
### Purpose: Send data across the socket to the LocoBufferServer

    def send(self, data):
        self._write_lock.acquire()
        #print "data", LocoLib.convertToStandardMessage(data)
        try:
            self.socket.sendall(data)
        except:
            print "Message failed ",  LocoLib.convertToStandardMessage(data)
        finally:
            self._write_lock.release()

### Function: close
### Purpose: Close the socket and join with the reader thread.

    def close(self):
        self.alive = False
        self.readerThread.join()



### LIBRARY FUNCTIONS ###

### Function: getMsgSizeForByte
### Purpose: Return the number of bytes in the message given the first byte

class LocoLib:
    from helpers import helpers
    @staticmethod
    def prepMessage(binStr):
        binList = [binStr[start:start+8] for start in range(0, len(binStr), 8)]
        # x or of all bytes
        compVal = 0
        for byte in binList:
            compVal = compVal ^ int(byte, 2)
        
        onesComp = ""
        onesCompStr = h.intToBinStr(compVal)
        for bit in onesCompStr:
            if bit == "1": 
                onesComp += "0"
            else:
                onesComp += "1"
        
        retStr = ""
        for byte in binList:
            chr_byte = chr(int(byte, 2))
            retStr += chr_byte
        return (retStr + chr(int(onesComp, 2)))
        
    ## The following functions are supplied for interpreting the message and turning it back
    ## into hex, they come in pairs.
    
    @staticmethod
    def interpSensorNumber(low, high):
        a = low[1:8]
        b = high[4:8]
        c = 2 * (128 * int(b, 2) + int(a, 2) + 1)
        if high[2] == "0":
            c = c -1
        return c
    

    
    @staticmethod
    def moveTurnout(turnoutTuple):
        r""" Returns hex from Tuple
        >>> LocoLib.moveTurnout(OPC_SW_REQ('OPC_SW_REQ', 18, '1', '1'))
        '\x04\x00\xb0\x110n'
        """
        opc = "10110000"
        binStr = LocoLib.shiftHigh(int(turnoutTuple.switchNum)-1)
        binStr = binStr[8:16] + "00" + str(turnoutTuple.dir) + str(turnoutTuple.output) + binStr[4:8]
        return "\x04\x00" + LocoLib.prepMessage(opc+binStr)
        
    @staticmethod
    def interpTurnoutMsg(hexStr):
        r""" Returns a OPC_SW_REQ tuple filled out with the appropriate data members
        >>> LocoLib.interpTurnoutMsg("\xb0\x12\x30m")
        OPC_SW_REQ(command='OPC_SW_REQ', switchNum=19, output='1', dir='1')
        """
        binList = h.hexStrToBinList(hexStr)
        command = "OPC_SW_REQ"
        SW1 = binList[1]
        SW2 = binList[2]
        switchNum = 128 * (int(SW2, 2) & 0x0F) + int(SW1, 2) + 1
        output = SW2[3:4]
        dir = SW2[2:3]
        return OPC_SW_REQ(command, switchNum, output, dir)


    @staticmethod
    def changeSpeed(speedTuple):
        """ Returns hex from tuple
        >>> print(LocoLib.changeSpeed(OPC_LOCO_SPD('OPC_LOCO_SPD', 1, 4)))
        \x04\x00\xA0\x01\x04\x5A
        """
        opc = "10100000"
        slot = h.intToBinStr(speedTuple.slot)
        speed = h.intToBinStr(speedTuple.speed)
        return "\x04\x00" + LocoLib.prepMessage(opc+slot+speed)

    @staticmethod
    def interpSpeedMsg(hexStr):
        """ Interprets speed message and returns speed tuple
        >>> LocoLib.interpSpeedMsg("\xA0\x01\x04\x5A")
        OPC_LOCO_SPD(command='OPC_LOCO_SPD', slot=1, speed=4)
        """
        binList = h.hexStrToBinList(hexStr)
        command = "OPC_LOCO_SPD"
        slot = int(binList[1], 2)
        speed = int(binList[2], 2)
        return OPC_LOCO_SPD(command, slot, speed)

    @staticmethod
    def changeDirf(dirfTuple):
        """ Interprets tuple
        >>> print(LocoLib.changeDirf(OPC_LOCO_DIRF(command='OPC_LOCO_DIRF', slot=1, dir='1', lights='1', horn='1', bell='1')))
        \x04\x00\xA1\x01\x33\x6C
        """
        opc = "10100001"
        slot = h.intToBinStr(dirfTuple.slot)
        dirState = "00" + str(dirfTuple.dir) + str(dirfTuple.lights) + "00" + str(dirfTuple.horn) + str(dirfTuple.bell)
        return "\x04\x00" + LocoLib.prepMessage(opc+slot+dirState)
        
    @staticmethod
    def interpDirfMsg(hexStr):
        """ Interprets DIRF message and returns speed tuple
        >>> LocoLib.interpDirfMsg("\xA1\x01\x33\x6C")
        OPC_LOCO_DIRF(command='OPC_LOCO_DIRF', slot=1, dir='1', lights='1', horn='1', bell='1')
        """
        binList = h.hexStrToBinList(hexStr)
        command = "OPC_LOCO_DIRF"
        slot = int(binList[1], 2)
        dirState = binList[2]
        dir = dirState[2]
        lights = dirState[3]
        horn = dirState[6]
        bell = dirState[7]
        return OPC_LOCO_DIRF(command, slot, dir, lights, horn, bell)
        
    @staticmethod
    def changeSnd(sndTuple):
        """ Interprets
        >>> print(LocoLib.changeSnd(OPC_LOCO_SND(command='OPC_LOCO_SND', slot=1, mute='1')))
        \x04\x00\xA2\x01\x08\x54
        """
        opc = "10100010"
        slot = h.intToBinStr(sndTuple.slot)
        sound = "0000" + sndTuple.mute + "000"
        return "\x04\x00" + LocoLib.prepMessage(opc+slot+sound)
        
    @staticmethod
    def interpSndMsg(hexStr):
        """ Interprets SND message and returns speed tuple
        >>> LocoLib.interpSndMsg("\xA2\x01\x08\x54")
        OPC_LOCO_SND(command='OPC_LOCO_SND', slot=1, mute='1')
        """
        binList = h.hexStrToBinList(hexStr)
        command = "OPC_LOCO_SND"
        slot = int(binList[1], 2)
        sound = binList[2]
        mute = sound[4:5]
        return OPC_LOCO_SND(command, slot, mute)

    @staticmethod
    def interpSensorReport(hexStr):
        r""" Interprets Sensor Report and returns a tuple
        >>> LocoLib.interpSensorReport("\xb2\x7f\x10\x00")
        OPC_INPUT_REP(command='OPC_INPUT_REP', sensor=255, hl='1')
        """
        binList = h.hexStrToBinList(hexStr)
        command = "OPC_INPUT_REP"
        SN1 = binList[1]
        SN2 = binList[2]
        sensor = LocoLib.interpSensorNumber(SN1, SN2)
        hl = SN2[3]
        return OPC_INPUT_REP(command, sensor, hl)

    @staticmethod
    def interpTurnoutReport(hexStr):
        """ Interprets Turnout Report and returns a tuple
        >>> LocoLib.interpTurnoutReport("\xB1\x12\x10\x4C")
        OPC_SW_REP(command='OPC_SW_REP', switchNum=19, hl='1')
        """
        binList = h.hexStrToBinList(hexStr)
        command = "OPC_SW_REP"
        SW1 = binList[1]
        SW2 = binList[2]
        switchNum = 128 * (int(SW2, 2) & 0x0F) + int(SW1, 2) + 1
        hl = SW2[3]
        return OPC_SW_REP(command, switchNum, hl)
        
    @staticmethod
    def powerOn():
        """ Return power on hex
        >>> LocoLib.powerOn()
        '\\x02\\x00\\x83|'
        """
        opc = "10000011" # 0x83
        return "\x02\x00" + LocoLib.prepMessage(opc)
    
    @staticmethod
    def powerOff():
        """ Return power off hex
        >>> LocoLib.powerOff()
        '\\x02\\x00\\x81~'
        """
        opc = "10000001"
        return "\x02\x00" + LocoLib.prepMessage(opc)
        
    @staticmethod
    def moveSlots(sltTuple):
        """ Interprets OPC_MOVE_SLOTS and returns hex
        >>> LocoLib.moveSlots(OPC_MOVE_SLOTS(command='OPC_MOVE_SLOTS', slotSrc=4, slotDst=4))
        '\\x04\\x00\\xba\\x04\\x04E'
        """
        opc = "10111010"
        slotSrc = h.intToBinStr(sltTuple.slotSrc)
        slotDst = h.intToBinStr(sltTuple.slotDst)
        return "\x04\x00" + LocoLib.prepMessage(opc+slotSrc+slotDst)
        
    @staticmethod
    def interpMoveSlots(hexStr):
        """ Interprets Move Slots message and returns a tuple
        >>> LocoLib.interpMoveSlots("\xBA\x04\x04\x69")
        OPC_MOVE_SLOTS(command='OPC_MOVE_SLOTS', slotSrc=4, slotDst=4)
        """
        binList = h.hexStrToBinList(hexStr)
        command = "OPC_MOVE_SLOTS"
        slotSrc = int(binList[1], 2)
        slotDst = int(binList[2], 2)
        return OPC_MOVE_SLOTS(command, slotSrc, slotDst)

    @staticmethod
    def locoAdr(locoTuple):
        r""" Interps Loco Adr tuple into hex
        >>> LocoLib.locoAdr(OPC_LOCO_ADR(command='OPC_LOCO_ADR', locoAdr=511))
        '\x04\x00\xbf\x03\x7f<'
        """
        opc = "10111111"
        locoAdr = h.intToBinStr(locoTuple.locoAdr, 65536, 0x8000, 16)
        locoAdr =  locoAdr[1:8]+locoAdr[8]+"0"+locoAdr[9:]
        temp = "\x04\x00" + LocoLib.prepMessage(opc+locoAdr)
        return temp

    @staticmethod
    def interpLocoAdr(hexStr):
        """ Interps Loco Adr message ant returns a tuple
        >>> LocoLib.interpLocoAdr("\xbf\x03\x7f\x3c")
        OPC_LOCO_ADR(command='OPC_LOCO_ADR', locoAdr=511)
        """
        binList = h.hexStrToBinList(hexStr)
        command = "OPC_LOCO_ADR"
        adrHigh = binList[1]
        adrLow = binList[2]
        locoAdr = int("0"+adrHigh[0:8]+adrLow[1:8], 2)
        return OPC_LOCO_ADR(command, locoAdr)
        
    @staticmethod
    def interpLongAck(hexStr):
        r""" Interps Long Ack and returns a tuple
        >>> LocoLib.interpLongAck("\xB4\x00\x00\x4B")
        OPC_LONG_ACK(command='OPC_LONG_ACK', lopc=0)
        """
        binList = h.hexStrToBinList(hexStr)
        command = "OPC_LONG_ACK"
        lopc = int(binList[1], 2)
        return OPC_LONG_ACK(command, lopc)

    @staticmethod
    def interpSlotData(hexStr):
        r""" Interps Slot Read Data
        >>> LocoLib.interpSlotData('\xE7\x0E\x01\x00\x7f\x00\x00\x00\x00\x01\x00\x00\x00\x00')
        OPC_SL_RD_DATA(command='OPC_SL_RD_DATA', slot=1, status='00', adr=255)
        """
        binList = h.hexStrToBinList(hexStr)
        command = "OPC_SL_RD_DATA"
        slot = int(binList[2], 2)
        status = binList[3][2:4]
        adr = LocoLib.unshiftHigh(binList[9], binList[4])
        return OPC_SL_RD_DATA(command, slot, status, adr, chr(len(hexStr))+"\x00"+hexStr)
        
        
# The following are Dr. O's added messages

    @staticmethod
    def shiftHigh(adr):
        r""" Interps binary string of physical loco adr and sensor adr
        >>> LocoLib.shiftHigh(257)
        '0000001000000001'
        """
        adr = h.intToBinStr(adr, 65535, 0x8000, 16)
        adr = adr[1:9] + "0" + adr[9:16]
        return adr
    
    @staticmethod
    def unshiftHigh(high, low):
        r""" Interps high, low and returns decimal for loco adr and sensor adr
        >>> LocoLib.unshiftHigh("00000010", "00000001")
        257
        """
        adr = "0" + high[0:8] + low[1:8]
        return int(adr, 2)

    @staticmethod
    def doLocoInit(initTuple):
        r""" Interps tuple and turns it into hex
        >>> LocoLib.doLocoInit(DO_LOCO_INIT(command='DO_LOCO_INIT', pLocoAdr=1111, count=2, sensorList=[251, 255]))
        '\x06\x00\x00\x08\x08W\x02\x01{\x01\x7f\xae'
        """
        opc = "00000000"
        msgNum = "00001000"
        pLocoAdr = LocoLib.shiftHigh(initTuple.pLocoAdr)
        count = h.intToBinStr(initTuple.count)
        sStr = ""
        for sensor in initTuple.sensorList:
            sensor_string = LocoLib.shiftHigh(sensor)
            sStr += sensor_string
        return chr(initTuple.count*2 + 6) + "\x00" + LocoLib.prepMessage(opc+msgNum+pLocoAdr+count+sStr) 

    @staticmethod
    def interpDoLocoInit(hexStr):
        r""" Interps Do Loco Init message and returns a tuple
        >>> LocoLib.interpDoLocoInit('\x00\x08\x00\x07\x04\x00\x01\x00\x02\x00\x03\x02\x01\xf7')
        DO_LOCO_INIT(command='DO_LOCO_INIT', pLocoAdr=7, count=4, sensorList=[1, 2, 3, 257])
        """
        binList = h.hexStrToBinList(hexStr)
        command = "DO_LOCO_INIT"
        pLocoAdr = LocoLib.unshiftHigh(binList[2],binList[3])
        count = int(binList[4], 2) * 2
        sensorList = []
        for i in range(5, count+4, 2):
            sen_num = LocoLib.unshiftHigh(binList[i], binList[i+1])
            sensorList.append(sen_num)
        return DO_LOCO_INIT(command, pLocoAdr, int(binList[4], 2), sensorList)

    @staticmethod
    def putInitOutcome(initTuple):
        r""" Interps tuple and turns it into hex
        >>> LocoLib.putInitOutcome(PUT_INIT_OUTCOME(command='PUT_INIT_OUTCOME', pAdr=257, pSlot=4, vAdr=1, vSlot=2))
        '\t\x00\x00\t\x02\x01\x04\x00\x01\x02\xf2'
        """
        opc = "00000000"
        msgNum = "00001001"
        pAdr = LocoLib.shiftHigh(initTuple.pAdr)
        pSlot = h.intToBinStr(initTuple.pSlot)
        vAdr = LocoLib.shiftHigh(initTuple.vAdr)
        vSlot = h.intToBinStr(initTuple.vSlot)
        return "\x09\x00" + LocoLib.prepMessage(opc+msgNum+pAdr+pSlot+vAdr+vSlot) 

    @staticmethod
    def interpPutInitOutcome(hexStr):
        r""" Interps Put Init Outcome message and returns a tuple
        >>> LocoLib.interpPutInitOutcome('\x00\x09\x02\x01\x04\x00\x01\x02\xf2')
        PUT_INIT_OUTCOME(command='PUT_INIT_OUTCOME', pAdr=257, pSlot=4, vAdr=1, vSlot=2)
        """
        binList = h.hexStrToBinList(hexStr)
        command = "PUT_INIT_OUTCOME"
        pAdr = LocoLib.unshiftHigh(binList[2], binList[3])
        pSlot = int(binList[4], 2)
        vAdr = LocoLib.unshiftHigh(binList[5], binList[6])
        vSlot = int(binList[7], 2)
        return PUT_INIT_OUTCOME(command, pAdr, pSlot, vAdr, vSlot)
    
    @staticmethod
    def putTrainState(trainTuple):
        r""" train state tuple
        >>> LocoLib.putTrainState(PUT_TRAIN_STATE('PUT_TRAIN_STATE', 3, 1))
        '\x05\x00\x00\x01\x03\x01\xfc'
        """
        opc = "00000000"
        msgNum = "00000001"
        slot = h.intToBinStr(trainTuple.slot)
        state = h.intToBinStr(trainTuple.state)
        return "\x05\x00" + LocoLib.prepMessage(opc+msgNum+slot+state) 
    
    @staticmethod
    def interpPutTrainState(hexStr):
        r""" Interps train state message
        >>> LocoLib.interpPutTrainState('\x00\x01\x03\x01\xfc')
        PUT_TRAIN_STATE(command='PUT_TRAIN_STATE', slot=3, state=1)
        """
        binList = h.hexStrToBinList(hexStr)
        command = "PUT_TRAIN_STATE"
        slot = int(binList[2], 2)
        state = int(binList[3], 2)
        return PUT_TRAIN_STATE(command, slot, state)
    
    @staticmethod
    def putTrainPosition(trainTuple):
        r""" train position tuple
        >>> LocoLib.putTrainPosition(PUT_TRAIN_POSITION('PUT_TRAIN_POSITION', 3, [1, 257, 3]))
        '\x0b\x00\x00\x02\x03\x03\x00\x01\x02\x01\x00\x03\xfc'
        """
        opc = "00000000"
        msgNum = "00000010"
        slot = h.intToBinStr(trainTuple.slot)
        count = h.intToBinStr(len(trainTuple.sensorList))
        sStr = ""
        for sensor in trainTuple.sensorList:
            sensor_string = LocoLib.shiftHigh(sensor)
            sStr += sensor_string
        chrInt = int(count, 2) * 2 + 5
        return chr(chrInt) + "\x00" + LocoLib.prepMessage(opc+msgNum+slot+count+sStr) 
        
    @staticmethod
    def interpPutTrainPosition(hexStr):
        r""" Interps train position message
        >>> LocoLib.interpPutTrainPosition('\x00\x02\x03\x03\x00\x01\x02\x01\x00\x03\xfc')
        PUT_TRAIN_POSITION(command='PUT_TRAIN_POSITION', slot=3, sensorList=[1, 257, 3])
        """
        binList = h.hexStrToBinList(hexStr)
        command = "PUT_TRAIN_POSITION"
        slot = int(binList[2], 2)
        count = int(binList[3], 2) * 2
        sensorList = []
        for i in range(4, count+4, 2):
            sen_num = LocoLib.unshiftHigh(binList[i], binList[i+1])
            sensorList.append(sen_num)
        return PUT_TRAIN_POSITION(command, slot, sensorList)
    
    @staticmethod
    def putSectionState(sectionTuple):
        r""" train section tuple
        >>> LocoLib.putSectionState(PUT_SECTION_STATE('PUT_SECTION_STATE', 4, 1))
        '\x06\x00\x00\x03\x00\x04\x01\xf9'
        """
        opc = "00000000"
        msgNum = "00000011"
        section = LocoLib.shiftHigh(sectionTuple.section)
        state = h.intToBinStr(sectionTuple.state)
        return "\x06\x00" + LocoLib.prepMessage(opc+msgNum+section+state)
    
    @staticmethod
    def interpPutSectionState(hexStr):
        r""" Interps section state msg
        >>> LocoLib.interpPutSectionState('\x00\x03\x00\x04\x01\xf9')
        PUT_SECTION_STATE(command='PUT_SECTION_STATE', section=4, state=1)
        """
        binList = h.hexStrToBinList(hexStr)
        command = "PUT_SECTION_STATE"
        section = LocoLib.unshiftHigh(binList[2], binList[3])
        state = int(binList[4], 2)
        return PUT_SECTION_STATE(command, section, state)
    
    @staticmethod
    def putSwitchState(switchTuple):
        r""" train section tuple
        >>> LocoLib.putSwitchState(PUT_SWITCH_STATE('PUT_SWITCH_STATE', 4, 1))
        '\x06\x00\x00\x04\x04\x01\xfe'
        """
        opc = "00000000"
        msgNum = "00000100"
        switch = h.intToBinStr(switchTuple.switch)
        state = h.intToBinStr(switchTuple.state)
        return "\x05\x00" + LocoLib.prepMessage(opc+msgNum+switch+state)
    
    @staticmethod
    def interpPutSwitchState(hexStr):
        r""" Interps switch state msg
        >>> LocoLib.interpPutSwitchState('\x00\x04\x04\x01\xfe')
        PUT_SWITCH_STATE(command='PUT_SWITCH_STATE', switch=4, state=1)
        """
        binList = h.hexStrToBinList(hexStr)
        command = "PUT_SWITCH_STATE"
        switch = int(binList[2], 2)
        state = int(binList[3], 2)
        return PUT_SWITCH_STATE(command, switch, state)
    
    @staticmethod
    def putSensorState(sensorTuple):
        r""" sensor state tuple
        >>> LocoLib.putSensorState(PUT_SENSOR_STATE('PUT_SENSOR_STATE', 4, 1))
        '\x05\x00\x00\x05\x00\x04\x01\xff'
        """
        opc = "00000000"
        msgNum = "00000101"
        sensor = LocoLib.shiftHigh(sensorTuple.sensor)
        state = h.intToBinStr(sensorTuple.state)
        return "\x06\x00" + LocoLib.prepMessage(opc+msgNum+sensor+state)
    
    @staticmethod
    def interpPutSensorState(hexStr):
        r""" Interps sensor state msg
        >>> LocoLib.interpPutSensorState('\x00\x05\x00\x04\x01\xff')
        PUT_SENSOR_STATE(command='PUT_SENSOR_STATE', sensor=4, state=1)
        """
        binList = h.hexStrToBinList(hexStr)
        command = "PUT_SENSOR_STATE"
        sensor = LocoLib.unshiftHigh(binList[2], binList[3])
        state = int(binList[4], 2)
        return PUT_SENSOR_STATE(command, sensor, state)
    
    @staticmethod
    def msgTryToMoveAgain(mTuple):
        r""" try move again
        >>> LocoLib.msgTryToMoveAgain(MSG_TRY_MOVE_AGAIN('MSG_TRY_MOVE_AGAIN'))
        '\x03\x00\x00\x10\xef'
        """
        opc = "00000000"
        msgNum = "00010000"
        return "\x03\x00" + LocoLib.prepMessage(opc+msgNum)
        
    @staticmethod
    def interpMsgTryMoveAgain(hexStr):
        r""" Interps try again
        >>> LocoLib.interpMsgTryMoveAgain('\x03\x00\x00\x10\xef')
        MSG_TRY_MOVE_AGAIN(command='MSG_TRY_MOVE_AGAIN')
        """
        command = "MSG_TRY_MOVE_AGAIN"
        return MSG_TRY_MOVE_AGAIN(command)
    
    @staticmethod
    def msgFrontSensorFired(sensorTuple):
        r""" front sensor fired
        >>> LocoLib.msgFrontSensorFired(MSG_FRONT_SENSOR_FIRED('MSG_FRONT_SENSOR_FIRED', 4))
        '\x04\x00\x00\x11\x04\xea'
        """
        opc = "00000000"
        msgNum = "00010001"
        trainId = h.intToBinStr(sensorTuple.trainId)
        return "\x04\x00" + LocoLib.prepMessage(opc+msgNum+trainId)
    
    @staticmethod
    def interpMsgFrontSensorFired(hexStr):
        r""" Interps front sensor fired message
        >>> LocoLib.interpMsgFrontSensorFired('\x00\x11\x04\xea')
        MSG_FRONT_SENSOR_FIRED(command='MSG_FRONT_SENSOR_FIRED', trainId=4)
        """
        binList = h.hexStrToBinList(hexStr)
        command = "MSG_FRONT_SENSOR_FIRED"
        trainId = int(binList[2], 2)
        return MSG_FRONT_SENSOR_FIRED(command, trainId)
       
    @staticmethod
    def msgBackSensorFired(sensorTuple):
        r""" back sensor fired
        >>> LocoLib.msgBackSensorFired(MSG_BACK_SENSOR_FIRED('MSG_BACK_SENSOR_FIRED', 4))
        '\x04\x00\x00\x12\x04\xe9'
        """
        opc = "00000000"
        msgNum = "00010010"
        trainId = h.intToBinStr(sensorTuple.trainId)
        return "\x04\x00" + LocoLib.prepMessage(opc+msgNum+trainId)
        
    @staticmethod
    def interpMsgBackSensorFired(hexStr):
        r""" Interps front sensor fired message
        >>> LocoLib.interpMsgBackSensorFired('\x00\x12\x04\xe9')
        MSG_BACK_SENSOR_FIRED(command='MSG_BACK_SENSOR_FIRED', trainId=4)
        """
        binList = h.hexStrToBinList(hexStr)
        command = "MSG_BACK_SENSOR_FIRED"
        trainId = int(binList[2], 2)
        return MSG_BACK_SENSOR_FIRED(command, trainId)

    @staticmethod
    def msgSensorError(sensorTuple):
        r""" sensor error
        >>> LocoLib.msgSensorError(MSG_SENSOR_ERROR('MSG_SENSOR_ERROR', 4))
        '\x04\x00\x00\x13\x00\x04\xe8'
        """
        opc = "00000000"
        msgNum = "00010011"
        sensor = LocoLib.shiftHigh(sensorTuple.sensor)
        return "\x05\x00" + LocoLib.prepMessage(opc+msgNum+sensor)

    @staticmethod
    def interpSensorError(hexStr):
        r""" Interps sensor error
        >>> LocoLib.interpSensorError('\x00\x13\x00\x04\xe9')
        MSG_SENSOR_ERROR(command='MSG_BACK_SENSOR_FIRED', sensor=4)
        """
        binList = h.hexStrToBinList(hexStr)
        command = "MSG_BACK_SENSOR_FIRED"
        sensor = LocoLib.unshiftHigh(binList[2], binList[3])
        return MSG_SENSOR_ERROR(command, sensor)

    @staticmethod
    def msgLoseReservation(trainTuple):
        r""" lose reservation
        >>> LocoLib.msgLoseReservation(MSG_LOSE_RESERVATION('MSG_LOSE_RESERVATION', 4))
        '\x04\x00\x00\x14\x04\xef'
        """
        opc = "00000000"
        msgNum = "00010100"
        trainId = h.intToBinStr(trainTuple.trainId)
        return "\x04\x00" + LocoLib.prepMessage(opc+msgNum+trainId)
        
    @staticmethod
    def interpMsgLoseReservation(hexStr):
        r""" Interps lose reservation
        >>> LocoLib.interpMsgLoseReservation('\x00\x14\x04\xef')
        MSG_LOSE_RESERVATION(command='MSG_LOSE_RESERVATION', trainId=4)
        """
        binList = h.hexStrToBinList(hexStr)
        command = "MSG_LOSE_RESERVATION"
        trainId = int(binList[2], 2)
        return MSG_LOSE_RESERVATION(command, trainId)

    @staticmethod
    def putTrainInformation(trainTuple):
        r""" train information
        >>> LocoLib.putTrainInformation(PUT_TRAIN_INFORMATION('PUT_TRAIN_INFORMATION', 4, 7, 1, 1, 1, 1, 1))
        '\n\x00\x00\x15\x04\x07\x01\x01\x01\x01\x01\xe8'
        """
        opc = "00000000"
        msgNum = "00010101"
        slot = h.intToBinStr(trainTuple.slot)
        speed = h.intToBinStr(trainTuple.speed)
        dir = h.intToBinStr(trainTuple.dir)
        light = h.intToBinStr(trainTuple.light)
        bell = h.intToBinStr(trainTuple.bell)
        horn = h.intToBinStr(trainTuple.horn)
        mute = h.intToBinStr(trainTuple.mute)
        return "\x0a\x00" + LocoLib.prepMessage(opc+msgNum+slot+speed+dir+light+bell+horn+mute)

    @staticmethod
    def interpPutTrainInformation(hexStr):
        r""" Interps train information
        >>> LocoLib.interpPutTrainInformation('\x00\x15\x04\x07\x01\x01\x01\x01\x01\xef')
        PUT_TRAIN_INFORMATION(command='PUT_TRAIN_INFORMATION', slot=4, speed=7, dir=1, light=1, bell=1, horn=1, mute=1)
        """
        binList = h.hexStrToBinList(hexStr)
        command = "PUT_TRAIN_INFORMATION"
        slot = int(binList[2], 2)
        speed = int(binList[3], 2)
        dir = int(binList[4], 2)
        light = int(binList[5], 2)
        bell = int(binList[6], 2)
        horn = int(binList[7], 2)
        mute = int(binList[8], 2)
        return PUT_TRAIN_INFORMATION(command, slot, speed, dir, light, bell, horn, mute)
        
    @staticmethod
    def getSwitchStates(switchTuple):
        r""" get switch states
        >>> LocoLib.getSwitchStates(GET_SWITCH_STATES('GET_SWITCH_STATES'))
        '\x03\x00\x00\x16\xe9'
        """
        opc = "00000000"
        msgNum = "00010110"
        return "\x03\x00" + LocoLib.prepMessage(opc+msgNum)
        
    @staticmethod
    def interpGetSwitchStates(hexStr):
        r""" Interps get switch states
        >>> LocoLib.interpGetSwitchStates('\x00\x16\xef')
        GET_SWITCH_STATES(command='GET_SWITCH_STATES')
        """
        binList = h.hexStrToBinList(hexStr)
        command = "GET_SWITCH_STATES"
        return GET_SWITCH_STATES(command)
        
    @staticmethod	
    def convertToStandardMessage(msg):
        if msg is None: return None
        msg = msg[2:]
        if (ord(msg[0]) == 0xB1):
            return LocoLib.interpTurnoutReport(msg)
        if (ord(msg[0]) == 0xB2):
            return LocoLib.interpSensorReport(msg)
        if (ord(msg[0]) == 0xA2):
            return LocoLib.interpSndMsg(msg)
        if (ord(msg[0]) == 0xA1):
            return LocoLib.interpDirfMsg(msg)
        if (ord(msg[0]) == 0xA0):
            return LocoLib.interpSpeedMsg(msg)
        if (ord(msg[0]) == 0xB0):
            return LocoLib.interpTurnoutMsg(msg)
        if (ord(msg[0]) == 0xE7):
            return LocoLib.interpSlotData(msg)
        if (ord(msg[0]) == 0xB4):
            return LocoLib.interpLongAck(msg)
        if (ord(msg[0]) == 0xBF):
            return LocoLib.interpLocoAdr(msg)
        if (ord (msg[0]) == 0xBA):
            return LocoLib.interpMoveSlots(msg)
        if (ord (msg[0]) == 0x00):
            if (ord (msg[1]) == 0x11):
                return LocoLib.interpMsgFrontSensorFired(msg)
        if (ord (msg[0]) == 0x00):
            if (ord (msg[1]) == 0x08):
                return LocoLib.interpDoLocoInit(msg)
            if (ord (msg[1]) == 0x09):
                return LocoLib.interpPutInitOutcome(msg)
            if (ord (msg[1]) == 0x03):
                return LocoLib.interpPutSectionState(msg)
            if (ord (msg[1]) == 0x04):
                return LocoLib.interpPutSwitchState(msg)
            if (ord (msg[1]) == 0x01):
                return LocoLib.interpPutTrainState(msg)
            if (ord (msg[1]) == 0x02):
                return LocoLib.interpPutTrainPosition(msg)
        return MSG_TRY_MOVE_AGAIN('MSG_TRY_MOVE_AGAIN')

    @staticmethod
    def messageIsLayoutMessage(msg):
        if msg.command == "OPC_SW_REQ":
            return True
        elif msg.command == "OPC_INPUT_REP":
            return True
        elif msg.command == "OPC_SW_REP":
            return True
        elif msg.command == "OPC_MOVE_SLOTS":
            return True
        elif msg.command == "MSG_SENSOR_ERROR":
            return True
        return False

    @staticmethod
    def messageIsTrainMessage(msg):
        if msg.command == "OPC_LOCO_SPD":
            return True
        elif msg.command == "OPC_LOCO_SPD":
            return True
        elif msg.command == "OPC_LOCO_SND":
            return True
        elif msg.command == "OPC_LOCO_DIRF":
            return True
        elif msg.command == "MSG_FRONT_SENSOR_FIRED":
            return True
        elif msg.command == "MSG_BACK_SENSOR_FIRED":
            return True
        elif msg.command == "MSG_LOSE_RESERVATION":
            return True
        elif msg.command == "MSG_TRY_MOVE_AGAIN":
            return True
        return False

    @staticmethod
    def messageIsRegistrationMessage(msg):
        if msg.command == "OPC_LOCO_ADR":
            return True
        elif msg.command == "OPC_SL_RD_DATA":
            return True
        elif msg.command == "DO_LOCO_INIT":
            return True
        return False
    
    @staticmethod
    def convertToLocoMessage(msg):
        if msg is None: return None
        if msg.command == "OPC_SW_REP":
            return None
        if msg.command == "OPC_INPUT_REP":
            return None
        if msg.command == "OPC_LOCO_SND":
            return LocoLib.changeSnd(msg)
        if msg.command == "OPC_LOCO_SPD":
            return LocoLib.changeSpeed(msg)
        if msg.command == "OPC_LOCO_DIRF":
            return LocoLib.changeDirf(msg)
        if msg.command == "OPC_SW_REQ":
            return LocoLib.moveTurnout(msg)
        return None

if __name__ == '__main__':
    doctest.testmod()
