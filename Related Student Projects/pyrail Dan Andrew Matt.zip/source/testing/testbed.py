### A file to perform external tests on pyrail componenets -- So as to not to increase length of function...Andrew ;)


import doctest

class testbed:

    @staticmethod
    def testSlotLookupTable():
        """ This function creates a SlotLookupTable,
            does some operations on it, and verifies the correct operation of the data structure.
        >>> from pyrailobjects import *
        >>> q = ProtectedQueue()
        >>> t1 = Train(q)
        >>> t2 = Train(q)
        >>> t2.pAddr = 2
        >>> t2.vAddr = 2
        >>> t2.pSlot = 2
        >>> t2.vSlot = 2
        >>> t = SlotLookupTable()
        >>> t.addEntry(t1)
        >>> t.addEntry(t2)
        >>> for e in t.entries: print e
        {'pSlot': -1, 'pAddr': -1, 'vAddr': -1, 'vSlot': -1}
        {'pSlot': 2, 'pAddr': 2, 'vAddr': 2, 'vSlot': 2}
        >>> import testbed
        >>> testbed.testSlotLookupTable()
        """
        return

if __name__ == '__main__':
    doctest.testmod()
