# Echo client program
import socket, time

HOST = '127.0.0.1'    # The remote host
PORT = 7245             # The same port as used by the server
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.connect((HOST, PORT))
while 1:
    data = s.send('\xb0\x11\x10\P')
    time.sleep(2)