import socket
import sys

class simplerailserver:

    def __init__(self, port, verbose):
        self.port = port
        self.verbose = verbose
    
    def runServer(self):
        host = ''
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.bind((host, self.port))
        s.listen(1)
        conn, addr = s.accept()
        running = True
        if self.verbose: print 'Connected by', addr
        while running:
            try:
                data = conn.recv(1024)
                if not data: break
                if self.verbose: print 'Received ', repr(data)
            except Exceptions as e:
                conn.close()
                running = False
        print "Goodbye!"

if __name__ == '__main__':
    s = simplerailserver(3030, True)
    s.runServer()
