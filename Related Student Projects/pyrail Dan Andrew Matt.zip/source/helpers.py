import socket
import doctest

class helpers:
    @staticmethod
    def intToBinStr(inputVal, maxSize=255, bitTest=0x80, bitLength=8):
        """ Returns a string representation of the corresponding integer
        >>> helpers.intToBinStr(1111, 65536, 0x8000, 16)
        '0000010001010111'
        """
        if inputVal > maxSize:
            raise Exception("decToBinStr: Too many bits, 8 max")
        output = ""
        for i in range (1, bitLength+1):
            if (inputVal & bitTest):
                output = output + "1"
            else:
                output = output + "0"
            bitTest = bitTest >> 1
        return output
    
    @staticmethod
    def hexStrToBinList(hexStr):
        binStr = ""
        for char in hexStr:
            binStr += helpers.intToBinStr(ord(char))
        return [binStr[start:start+8] for start in range(0, len(binStr), 8)]
    
    @staticmethod
    def hexByteToBinStr(inputVal):
        inputVal = ord(inputVal) # convert from hex byte to a decimal ie \xb2 -> 178
        return helpers.intToBinStr(inputVal)

    @staticmethod
    def getMsgLen(handle, curByte):
        countFlag = curByte[0:3]
        if (countFlag == "100"):
            return 1, ""
        elif (countFlag == "101"):
            return 3, ""
        elif (countFlag == "110"):
            return 5, ""
        elif (countFlag == "111"):
            if (isinstance(handle, socket.socket)):
                curByte = helpers.hexByteToBinStr(handle.recv(1))
            else:
                #print "read 3 loco"
                curByte = helpers.hexByteToBinStr(handle.read(1))
                #print "done read 3 loco"
            count = int(curByte, 2)
            return (count-1), chr(int(curByte, 2)) 
        else:
            raise Exception("Optcode error: Not a valid optcode")

    @staticmethod
    def initBogusConnection(host, port):
        """ Initiates a socket connection to the given host and port.
            Instantly closes the connection.
            Purpose is to get a listener to exit the 'accept' loop.
        >>> from simplerailserver import *
        >>> import threading
        >>> serv = simplerailserver(15123, False)
        >>> t = threading.Thread(target=serv.runServer)
        >>> t.start()
        >>> helpers.initBogusConnection('localhost', 15123)
        >>> t.join()
        Goodbye!
        """
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.connect((host, port))
        sock.close()

if __name__ == '__main__':
    doctest.testmod()
