from pyrailobjects import *
from LocoLogic import *
from LocoLib import LocoLib

from xml.etree import ElementTree as ET
from sys import stdout as SO

class Section:

    def __init__(self, lm, xmlElem):
        self.lm = lm
        self.id = int(xmlElem.get('id'))
        self.switchDependencies = {}
        self.blockList = []
        self.blockCount = 0
        self.wide = " - "
        self.narrow = " - "
        for elem in xmlElem[:]:
            if elem.tag == 'sensor':
                if (elem.get('end') == 'wide' and self.wide == " - ") or self.narrow != " - ":
                    self.wide = int(elem.get('id'))
                else:
                    self.narrow = int(elem.get('id'))
            elif elem.tag == 'switch':
                self.switchDependencies[int(elem.get('id'))] = elem.get('state')
            elif elem.tag == 'blocking':
                self.blockList.append(int(elem.get('id')))
        self.fsm = FiniteStateMachine()
        self.fsm.object = self
        self.fsm.pushState(SectionStateFree(self.fsm))
        self.trainID = -1
        
    def isFree(self):
        if self.fsm.state.name == "free":
            return True
        return False
    
    def isBlocked(self):
        if self.fsm.state.name == "blocked":
            return True
        return False
    
    def isReserved(self):
        if self.fsm.state.name == "reserved":
            return True
        return False
        
    def isReservedForTrain(self, trainID):
        if self.fsm.state.name == "reserved" and self.trainID == trainID:
            return True
        return False
        
    def getReservedTrain(self):
        if self.fsm.state.name =="reserved":
            return self.trainID
        return -1
    
    def blockCount(self):
        return self.blockCount
        
    def incBlockCount(self):
        print "sec: ", self.id, " inc bc from ", self.blockCount
        if self.blockCount == 0:
            print "push block state"
            self.fsm.changeToState(SectionStateBlocked(self.fsm))
        self.blockCount = self.blockCount + 1
    
    def decBlockCount(self):
        print "in dbc for sec: ", self.id
        if self.blockCount > 0:
            print "sec: ", self.id, " dec bc from ", self.blockCount
            self.blockCount = self.blockCount - 1
            if self.blockCount == 0:
                self.fsm.changeToState(SectionStateFree(self.fsm))
    
    def reserve(self, trainID):
        self.trainID = trainID
        self.fsm.changeToState(SectionStateReserved(self.fsm))
        
    def releaseReservation(self):
        self.decBlockCount()
        self.fsm.changeToState(SectionStateFree(self.fsm))
        self.trainID = -1
        for sec in self.blockList:
            sec.decBlockCount()
        
    def occupy(self):
        self.fsm.changeToState(SectionStateOccupied(self.fsm))
        
    def isOccupied(self):
        if self.fsm.state.name == "occupied":
            return True
        return False
        
    def freeSection(self):
        print "section: ", self.id, " is free"
        self.fsm.changeToState(SectionStateFree(self.fsm))

    def printObj(self, indent):
        SO.write(indent + "                               ID: " + self.id + "\n")
        SO.write(indent + "Bounded by Sensors (wide, narrow): " + self.wide + ", " + self.narrow + "\n")
        if len(self.switchDependencies) > 0:
            SO.write(indent + "        Required Switches, States:")
            for key in self.switchDependencies:
                SO.write(" (" + key + ", " + self.switchDependencies[key] + ")")
            SO.write("\n")
        if len(self.blockList) > 0:
            SO.write(indent + "                           Blocks:")
            for b in self.blockList:
                SO.write(" " + b)
            SO.write("\n")

class Sensor:

    def __init__(self, lm, xmlElem):
        self.lm = lm
        self.id = int(xmlElem.get('id'))
        self.fsm = FiniteStateMachine()
        self.fsm.object = self
        self.fsm.pushState(SensorStateClosed(self.fsm))
        self.connectedSections = []

    def printObj(self, indent):
        SO.write(indent + "ID: " + self.id)

class Switch:

    def __init__(self, lm, xmlElem):
        self.blockWhenThrowing = []
        self.blockWhenClosing = []
        self.lm = lm
        self.id = int(xmlElem.get('id'))
        self.state = xmlElem.get('init')
        self.fsm = FiniteStateMachine()
        self.fsm.object = self
        if self.state == "thrown":
            self.fsm.state = SwitchStateThrown(self.fsm)
        else:
            self.fsm.state = SwitchStateClosed(self.fsm)

    def printObj(self, indent):
        SO.write(indent + "ID: " + self.id + " State: " + self.state)

class LayoutManager(BaseQueueReader):

    def __init__(self, filename, cqm):
        BaseQueueReader.__init__(self)
        self.cv = threading.Condition()
        self.sections = {}
        self.sensors = {}
        self.switches = {}
        self.cmdQM = cqm
        self.trainLocations = {}
        self.fsm = FiniteStateMachine()
        self.fsm.object = self
        self.fsm.pushState(LayoutManagerStateActive(self.fsm))
        self.initWithXML(filename)

    def handleMsg(self, msg):
        print "Layout received ", msg
        if msg is not None:
            self.fsm.handleMsg(msg)

    def moveSwitch(self, msg):
        self.switches[msg.switchNum].fsm.handleMsg(msg)

    def canMoveSwitch(self, switch):
        for sec in switch.blockWhenThrowing:
            if sec.isOccupied():
                return False
        for sec in switch.blockWhenClosing:
            if sec.isOccupied():
                return False
        return True

    def doMoveSwitch(self, switch, dir):
        if int(dir) == 0:
            for sec in switch.blockWhenThrowing:
                if sec.isReserved():
                    tid = sec.getReservedTrain()
                    msg = MSG_LOSE_RESERVATION('MSG_LOSE_RESERVATION', int(tid))
                    self.cmdQM.queue.addMsg(msg)
        else:
            for sec in switch.blockWhenClosing:
                if sec.isReserved():
                    tid = sec.getReservedTrain()
                    msg = MSG_LOSE_RESERVATION('MSG_LOSE_RESERVATION', int(tid))
                    self.cmdQM.queue.addMsg(msg)
        lmsg = LocoLib.moveTurnout(OPC_SW_REQ('OPC_SW_REQ', switch.id, '1', dir))
        self.cmdQM.locoTransmitter.send(lmsg)
    
    def setTrainLocation(self, trainID, locList):
        self.cv.acquire()
        newList = []
        for sid in locList:
        #    print "LocList", locList
            newList.append(self.sensors[sid])
        self.trainLocations[trainID] = newList
        #print "setTrainLocation:"
        #for sen in newList:
        #    print sen.id
        for i in range(0, len(newList) - 1):
            for sec in newList[i].connectedSections:
                if sec.wide == newList[i+1].id or sec.narrow == newList[i+1].id:
                    for bsec in sec.blockList:
                        bsec.incBlockCount()
                    sec.occupy()
        self.cv.notify()
        self.cv.release()
    
    def getTrainLocationList(self, trainID):
        list = []
        for sens in self.trainLocations[trainID]:
            list.append(sens.id)
        return list
    
    def switchTrainDirection(self, trainID):
        self.cv.acquire()
        self.trainLocations[trainID].reverse()
        self.cmdQM.locoTransmitter.send(LocoLib.putTrainPosition(PUT_TRAIN_POSITION('PUT_TRAIN_POSITION', trainID, self.getTrainLocationList(trainID))))
        self.cv.notify()
        self.cv.release()
    
    def advanceFrontOfTrain(self, trainID):
        self.cv.acquire()
        print "advancing front of train", trainID
        nextSect = self.getNextSection(trainID)
        if not nextSect.isReservedForTrain(trainID):
            print "SYSTEM ERROR IN ADVANCE FRONT OF TRAIN", trainID 
        locList = self.trainLocations[trainID]
        #print "nextsec: ", nextSect.id, "narr: ", nextSect.narrow, " wide: ", nextSect.wide, "LL[0]: ", locList[0].id
        if (nextSect.narrow == locList[0].id):
            # append wide
            self.trainLocations[trainID].insert(0, self.sensors[int(nextSect.wide)])
        else:
            # append narrow
            self.trainLocations[trainID].insert(0, self.sensors[int(nextSect.narrow)])
        print "advanceFrontOfTrain: new locations: "
        for sens in self.trainLocations[trainID]:
            print sens.id
        print "advanceFrontOfTrain: end locations"
        nextSect.occupy()
        self.cv.notify()
        self.cv.release()
        
    def advanceBackOfTrain(self, trainID):
        self.cv.acquire()
        print "advancing back of train", trainID
        locList = self.trainLocations[trainID]
        for sec in locList[len(locList) - 2].connectedSections:
            if sec.narrow == locList[len(locList) - 1].id or sec.wide == locList[len(locList) - 1].id:
                self.trainLocations[trainID] = locList[:-1]
                print "advanceBackOfTrain: new locations: "
                for sens in self.trainLocations[trainID]:
                    print sens.id
                print "advanceBackOfTrain: end locations"
                sec.freeSection()
                self.cv.notify()
                self.cv.release()
                return
        self.cv.notify()
        self.cv.release()

    def identifyTrain(self, sensorID):
        # logic for what train corresponds to it and either sending, 
        #  msgFrontSensorFired, msgBackSensorFired, or msgSensorError
        print "identifying train"
        self.cv.acquire()
        #print "sensorID: ", sensorID
        smsg = MSG_SENSOR_ERROR("MSG_SENSOR_ERROR", sensorID)
        lmsg = LocoLib.msgSensorError(MSG_SENSOR_ERROR("MSG_SENSOR_ERROR", sensorID))
        for tid in self.trainLocations.keys():
            lastIndex = len(self.trainLocations[tid]) - 1
            #print "tid: ", tid, " lastix: ", lastIndex, " locs: "
            #for sens in self.trainLocations[tid]:
            #    print sens.id
            #print "end ident train locs"
            #print "back Sens: ", self.trainLocations[tid][lastIndex - 1].id
            if int(self.trainLocations[tid][0].id) == sensorID:
                print "found first sensor", tid
                smsg = MSG_FRONT_SENSOR_FIRED("MSG_FRONT_SENSOR_FIRED", tid)
                lmsg = LocoLib.msgFrontSensorFired(MSG_FRONT_SENSOR_FIRED("MSG_FRONT_SENSOR_FIRED", tid))
            elif int(self.trainLocations[tid][lastIndex - 1].id) == sensorID:
                print "found back sensor", tid
                smsg = MSG_BACK_SENSOR_FIRED("MSG_BACK_SENSOR_FIRED", tid)
                lmsg = LocoLib.msgBackSensorFired(MSG_BACK_SENSOR_FIRED("MSG_BACK_SENSOR_FIRED", tid))
        #self.cmdQM.locoTransmitter.send(lmsg)
        self.cmdQM.queue.addMsg(smsg)
        self.cv.notify()
        self.cv.release()
    
    def getNextSection(self, trainID):
        frontSensor = self.trainLocations[trainID][0]
        backSensor = self.trainLocations[trainID][1] # back of section, not train
        occupiedSect = None
        nextSect = None
        #print "Front sensor: ", frontSensor.id
        #for sec in frontSensor.connectedSections:
        #    print sec.id
        #print "Back sensor: ", backSensor.id
        #for sec in backSensor.connectedSections:
        #    print sec.id
        for sec in frontSensor.connectedSections: # find occupied section
        #    print "Sec: ", sec.id, " Narrow: ", sec.narrow, "Wide: ", sec.wide
            if sec.wide == frontSensor.id and sec.narrow == backSensor.id:
                occupiedSect = sec
            elif sec.narrow == frontSensor.id and sec.wide == backSensor.id:
                occupiedSect = sec
        #print "occ sec: ", occupiedSect.id
        for sec in frontSensor.connectedSections: # find next
        #   print "Sec: ", sec.id, " Narrow: ", sec.narrow, "Wide: ", sec.wide
            if sec.id != occupiedSect.id:
        #        print "sec ", sec.id, " free :", sec.isFree()
                if sec.isFree() or sec.isReservedForTrain(trainID): # needed this for advanceFrontOfTrain but can we check to see if it's reserved by THAT train?
                    nextSect = sec 
                #notOnBlock = True
                #for bsec in occupiedSect.blockList:
                #    #print "BSec: ", bsec.id
                #    if sec.id == bsec.id:
                #        notOnBlock = False
                #if notOnBlock:
                #    nextSect = sec
        return nextSect
    
    def reserveNext(self, trainID):
        self.cv.acquire()
        nextSect = self.getNextSection(trainID)
        # print "tid: ", trainID, " reserving ", nextSect.id
        # print "list: "
        # for sens in self.trainLocations[trainID]:
        #    print sens.id
        if nextSect is not None and nextSect.isFree():
            nextSect.reserve(trainID)
            #print "nextSec.id : ", nextSect.id, " is free"
            #for depsect in nextSect.blockList:
            #    if (not depsect.isFree()):
                    #print " sect : ", depsect.id, " is not free"
            #        nextSect.releaseReservation()
            #        self.cv.notify()
            #        self.cv.release()
            #        return False
            print "reserved ", nextSect.id, " in state ", nextSect.fsm.state.name
            self.cv.notify()
            self.cv.release()
            return True
        #print "nextSect is either None or not free", nextSect.id, " train id ", trainID
        self.cv.notify()
        self.cv.release()
        return False

    def releaseReservation(self, tid):
        print "releaseReservation"
        nextSect = self.getNextSection(tid)
        if nextSect is not None:
            nextSect.releaseReservation()

    def initWithXML(self, filename):
        tree = ET.parse(filename)         # Parse the XML input file
        root = tree.getroot()             # Get the root element
        if root.tag != 'railroad':        # Set the root to the railroad root element
            root = root.find('railroad')
        if root:                          # Check for correct format
            for elem in root[:]:
                self.__parseSectionList(elem)
            for sec in self.sections.keys():
                newList = []
                for id in self.sections[sec].blockList:
                    newList.append(self.sections[id])
                self.sections[sec].blockList = newList
        
    def __parseSectionList(self, xmlElem):
        if xmlElem.tag == 'section-list':         # Generally only one
            for section in xmlElem[:]:
                self.__parseSection(section)

    def __parseSection(self, xmlElem):
        if xmlElem.tag == 'section':   # Verify this is actually a section
            newSec = Section(self, xmlElem)
            self.sections[newSec.id] = newSec
            for elem in xmlElem[:]:
                if elem.tag == 'sensor':
                    self.__parseSensor(elem, newSec)
                elif elem.tag == 'switch':
                    self.__parseSwitch(elem, newSec)
            return True
        return False

    def __parseSensor(self, xmlElem, sec):
        if xmlElem.tag == 'sensor':
            id = xmlElem.get('id')
            if int(id) not in self.sensors.keys():
                newSens = Sensor(self, xmlElem)
                newSens.connectedSections.append(sec)
                self.sensors[int(id)] = newSens
            else:
                sens = self.sensors[int(id)]
                sens.connectedSections.append(sec)
            return True
        return False

    def __parseSwitch(self, xmlElem, sec):
        if xmlElem.tag == 'switch':
            id = xmlElem.get('id')
            stateReq = xmlElem.get('state')
            #print "proc sw: ", id, " for sec: ", sec.id
            if int(id) not in self.switches:
                newSwitch = Switch(self, xmlElem)
                if stateReq == "thrown":
                    newSwitch.blockWhenClosing.append(sec)
                else:
                    newSwitch.blockWhenThrowing.append(sec)
                if xmlElem.get('init') != stateReq:
                    sec.incBlockCount()
                self.switches[int(id)] = newSwitch
                dir = 1
                if xmlElem.get('init') == "thrown":
                    dir = 0
                lmsg = LocoLib.moveTurnout(OPC_SW_REQ('OPC_SW_REQ', newSwitch.id, '1', dir))
                self.cmdQM.locoTransmitter.send(lmsg)
                #print "len bwc", len(self.switches[int(id)].blockWhenClosing)
                #print "len bwt", len(self.switches[int(id)].blockWhenThrowing)
            else:
                sw = self.switches[int(id)]
                if stateReq == "thrown":
                    sw.blockWhenClosing.append(sec)
                else:
                    sw.blockWhenThrowing.append(sec)
                if xmlElem.get('init') != stateReq:
                    sec.incBlockCount()
                #print "--len bwc", len(self.switches[int(id)].blockWhenClosing)
                #print "--len bwt", len(self.switches[int(id)].blockWhenThrowing)
            return True
        return False

    def saveXML(self, filename):
        # Not implemented yet
        return

    def printObj(self, indent):
        SO.write(indent + "Layout Manager Object\n")
        SO.write(indent + "Sections")
        self.__printIterFunc(self.sections, indent)
        SO.write(indent + "Switches")
        self.__printIterFunc(self.switches, indent)
        SO.write("\n" + indent + "Sensors")
        self.__printIterFunc(self.sensors, indent)

    def __printIterFunc(self, data, indent):
        if len(data) > 0:
            SO.write("\n")
            for key in data:
                data[key].printObj(indent + "  ")
                SO.write("\n")
        else:
            SO.write("\n")

if __name__ == "__main__":
    print "XML Test Script\n"
    layoutManager = LayoutManager("LabLayoutPart.xml")
    layoutManager.printObj("  ")
