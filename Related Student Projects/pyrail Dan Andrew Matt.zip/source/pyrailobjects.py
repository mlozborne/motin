## A file to define classes such as the queue manager, queues, etc.

import threading
from collections import deque
import sys
from LocoLib import *
from LocoLogic import *
import time

class ProtectedQueue:

    def __init__(self):
        self.queue = deque()
        self.cv = threading.Condition()

    def addMsg(self, msg):
        self.cv.acquire()
        self.queue.append(msg)
        self.cv.notify()
        self.cv.release()

    def removeMsg(self):
        self.cv.acquire()
        try:
            msg = self.queue.popleft()
        except IndexError:
            self.cv.wait()
            msg = self.queue.popleft()
        finally:
            self.cv.release()
        return msg

class SlotLookupTable:
    
    def __init__(self):
        self.entries = []  # Elements are dictionaries of relevant data
        self.pAddrs = {}   # These dictionaries give O(1) access
        self.vAddrs = {}   # Not necessary but facilitates the other
        self.pSlots = {}   # functions efficiency.
        self.vSlots = {}
        
    def addEntry(self, train):
        entry = { 'pAddr':train.pAddr, 
                  'vAddr':train.vAddr, 
                  'pSlot':train.pSlot, 
                  'vSlot':train.vSlot }
        self.entries.append(entry)
        self.pAddrs[train.pAddr] = entry
        self.vAddrs[train.vAddr] = entry
        self.pSlots[train.pSlot] = entry
        self.vSlots[train.vSlot] = entry

### Add as many of these access functions as you need
### Currently this class is not thread-safe, it might not ever need to be

    def getPhysSlotForVirtSlot(self, slot):
        try:
            entry = self.vAddrs[slot]
            return entry['pSLot']
        except:
            return None
            
    def getVirtSlotForPhysSlot(self, slot):
        try:
            entry = self.pAddrs[slot]
            return entry['vSLot']
        except:
            return None

    def getVirtAddrForVirtSlot(self, slot):
        try:
            entry = self.vSlots[slot]
            return entry['vAddr']
        except:
            return None

### Class: BaseQueueReader
### Purpose: Provide a base class for anyone that reads a queue.  This is encapsulating 
###          the "Task" notion and making it internal to each component of the system.
###          For example: Instead of having a Layout Task that reads a queue and calls 
###          methods in the LayoutManager, the LM has an internal thread that does this.
###          This class provides the basis of internal communication of the system.

class BaseQueueReader:

    def __init__(self):
        self.queue = ProtectedQueue()
        self.alive = True
        self.readerThread = threading.Thread(target=self.readerLoop)
        self.readerThread.start()

    def readerLoop(self):
        while self.alive:
            msg = self.queue.removeMsg()
            self.handleMsg(msg)
    
    def handleMsg(self, msg):
        # Leave this to the derived classes
        return

    def shutDown(self):
        self.alive = False

### Class: Train
### Purpose: Represent a train being controlled and provide functional logic regarding that train.
 
class Train(BaseQueueReader):

    def __init__(self):
        BaseQueueReader.__init__(self)
        self.pAddr = -1
        self.vAddr = -1
        self.pSlot = -1
        self.vSlot = -1
        self.speed = 0
        self.dir = '0'
        self.lights = '0'
        self.bell = '0'
        self.horn = '0'
        self.lm = None
        self.fsm = FiniteStateMachine()
        self.fsm.object = self
        self.fsm.state = TrainStateHalt(self.fsm)

    def handleMsg(self, msg):
        #print "Train ", self.vAddr, " received ", msg
        self.fsm.handleMsg(msg)

### Class: CommandQueueManager
### Purpose: Manage all queues and provide other functionality

class CommandQueueManager(BaseQueueReader):

    def __init__(self, lt):
        BaseQueueReader.__init__(self)
        self.alive = True
        self.allQueues = []
        self.locoTransmitter = lt
        self.slotLookupTable = SlotLookupTable()
        self.layoutManager = None
        #self.registerLayoutManager(lm)
        self.trains = {}
        self.trainRegistrar = TrainRegistrar()
        self.trainRegistrar.cqm = self
        self.readerThread = threading.Thread(target=self.readLocoBuffer)
        
    def handleMsg(self, msg):
        print "CQM: handleMsg: ", msg
        if LocoLib.messageIsTrainMessage(msg):
            self.forwardMessageToTrain(msg)
        elif LocoLib.messageIsLayoutMessage(msg):
            self.forwardMessageToLayout(msg)
        elif LocoLib.messageIsRegistrationMessage(msg):
            self.trainRegistrar.handleMsg(msg)
        else:
            sys.stderr.write("Unhandled message: %s\n" % msg.command)

    def readLocoBuffer(self):
        while self.locoTransmitter.connected:
            msg = self.locoTransmitter.readMsg()
            # handle message
            if msg is not None:
                sys.stderr.write("CQM Received: %s\n>>> " % repr(msg))
                stdMsg = LocoLib.convertToStandardMessage(msg)
                self.queue.addMsg(stdMsg)

    def registerLayoutManager(self, lm):
        self.allQueues.append(lm)
        self.layoutManager = lm

    def registerTrain(self, train, locList):
        train.lm = self.layoutManager
        self.slotLookupTable.addEntry(train)
        self.allQueues.append(train)
        self.trains[train.vAddr] = train
        self.layoutManager.setTrainLocation(train.vAddr, locList)
        newMsg = OPC_LOCO_DIRF('OPC_LOCO_DIRF', train.pSlot, train.dir, train.lights, train.horn, train.bell)
        self.locoTransmitter.send(LocoLib.changeDirf(newMsg))

    
    def shutDown(self):
        self.alive = False

    def forwardMessageToTrain(self, msg):
        tid = -1
        if msg.command == "MSG_FRONT_SENSOR_FIRED" or msg.command == "MSG_BACK_SENSOR_FIRED" or msg.command == "MSG_LOSE_RESERVATION":
            tid = msg.trainId
        elif msg.command == "MSG_TRY_MOVE_AGAIN":
            pass
        else:
            tid = self.slotLookupTable.getVirtAddrForVirtSlot(msg.slot)
        if tid is None:
            return
        for t in self.trains.values():
            if tid < 0:
                t.queue.addMsg(msg)
            elif t.vAddr == tid:
                t.queue.addMsg(msg)

    def forwardMessageToLayout(self, msg):
        self.layoutManager.queue.addMsg(msg)


class TrainRegistrar:

    def __init__(self):
        self.trains = {}
        self.trainLocations = {}
        self.doneList = {}
        self.nextVirtual = 1
        self.cqm = None

    def handleMsg(self, msg):
        #print "MSG.CMD", msg.command
        if msg.command == "DO_LOCO_INIT":
            if self.processingAddr(msg.pLocoAdr):
                None
            else:
                self.process(msg)
        elif msg.command == "OPC_SL_RD_DATA":
            #if msg.status == "11":
            #    return
            if self.processingAddr(msg.adr):
                mvsltmsg = LocoLib.moveSlots(OPC_MOVE_SLOTS("OPC_MOVE_SLOTS", msg.slot, msg.slot))
                self.cqm.locoTransmitter.send(mvsltmsg)
                self.trains[msg.adr].pSlot = msg.slot
                if self.trains[msg.adr].vSlot < 0:
                    self.doneList[self.trains[msg.adr].vAddr] = False
                    # send OPC_LOCO_ADR for vslot
                    oladata = LocoLib.locoAdr(OPC_LOCO_ADR("OPC_LOCO_ADR", self.trains[msg.adr].vAddr))
                    self.cqm.locoTransmitter.send(oladata)
            elif msg.adr in self.doneList.keys() and not self.doneList[msg.adr]:
                for t in self.trains.values():
                    if t.vAddr == msg.adr:
                        mvsltmsg = LocoLib.moveSlots(OPC_MOVE_SLOTS("OPC_MOVE_SLOTS", msg.slot, msg.slot))
                        self.cqm.locoTransmitter.send(mvsltmsg)
                        t.vSlot = msg.slot
                        self.cqm.registerTrain(t, self.trainLocations[t.pAddr])
                        # putInitOutcome
                        piodata = LocoLib.putInitOutcome(PUT_INIT_OUTCOME("PUT_INIT_OUTCOME", t.pAddr, t.pSlot, t.vAddr, t.vSlot))
                        self.doneList[t.pAddr] = True
                        self.doneList[t.vAddr] = True
                        time.sleep(0.05)
                        self.cqm.locoTransmitter.send(piodata)
                        return
            else:
                self.cqm.locoTransmitter.send(msg.hexStr)
        elif msg.command == "OPC_LOCO_ADR":
            self.cqm.locoTransmitter.send(LocoLib.locoAdr(msg))

    def processingAddr(self, addr):
        for t in self.trains.values():
            if t.pAddr == addr and not self.doneList[addr]:
                return True
        return False

    def process(self, msg):
        addr = msg.pLocoAdr
        self.doneList[addr] = False
        self.trains[addr] = Train()
        self.trains[addr].pAddr = addr
        self.trains[addr].vAddr = self.nextVirtual
        self.nextVirtual += 1
        self.trainLocations[addr] = msg.sensorList
        #send OPC_LOCO_ADR for pslot
        oladata = LocoLib.locoAdr(OPC_LOCO_ADR("OPC_LOCO_ADR", addr))
        self.cqm.locoTransmitter.send(oladata)
