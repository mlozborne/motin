###   PyRail Project - LocoBuffer Server
###   Authors: Matthew Preucil, Andrew Larsen (add if you edit)
###   Description: One thread reads the serial port.  Throttles/Pyrail/AdaRail can obtain a socket connection
###                by connecting to the specified port on the hosts IP address.  Each connection  receives  a
###                copy of the raw socket data coming in.  All data received by the connection is written  to
###                the LocoBuffer Serial port as well as being forwarded to all connections  except  the  one
###                that sent the data.
###   Description: Configurable to standard or simulated modes.  In standard mode, access  to the  LocoBuffer is
###                provided by a SerialInterface object.  In simulated mode, the LocoBuffer is a train simulator
###                accessed via a socket.  In either mode, an Interceptor object may or may not be in existence.
###                The standard Interceptor is PyRail.  If an Interceptor is connected, data from standard 
###                throttles is directed into its socket as if coming from the "LocoBuffer".  All data from the
###                "LocoBuffer" is picked up by the Interceptor and may or may not be forwarded to the standard
###                throttles.

import sys, os
import threading
import socket
import serial
from helpers import helpers as h
import copy as C
from LocoLib import *
import time

### Class SharedDataBuffer
### Purpose: Encapsulate the addition and retrieval of messages by multiple threads

class SharedDataBuffer:

    def __init__(self, condition):
        self.data = []
        self.observers = {}
        self.curIndex = 0
        self.numObservers = 0
        self.cv = condition
        self.active = True

    def registerObserver(self):
        self.cv.acquire()
        self.observers[self.numObservers] = self.curIndex
        r = self.numObservers
        self.numObservers += 1
        self.cv.release()
        return r
        
    def unregisterObserver(self, id):
        self.cv.acquire()
        self.observers[id] = None
        self.cv.release()


    def addData(self, data):
        self.cv.acquire()
        self.data.append(data)
        self.curIndex += 1
        self.cv.notifyAll()
        self.cv.release()

    def getDataForObserver(self, id):
        self.cv.acquire()
        while self.observers[id] >= self.curIndex and self.active:
            self.cv.wait()
        # Return a copy of data for the observer with id
        copy = None
        try:
            copy = C.deepcopy(self.data[self.observers[id]])
            self.observers[id] += 1
        finally:
            self.cv.release()
        return copy

### Class: LocoBufferCommunicator
### Purpose: Base object for communication with the "LocoBuffer", essentially a pure virtual class

class LocoBufferCommunicator:

    def __init__(self):
        self.cv = threading.Condition()
        self.dataBuffer = SharedDataBuffer(self.cv)
        self._write_lock = threading.Lock()
        self.alive = True
        self.filter = None
        self.closePort = -1 # When connection to LB dies, send bogus conection to this port

    def readLoop(self):
        return

    def write(self, data):
        return

    def doCleanup(self):
        if self.closePort > 0:
            h.initBogusConnection('localhost', self.closePort)

### Class: SerialInterface
### Purpose: Read from the serial port and store data in a shared resource

class SerialInterface(LocoBufferCommunicator):

    def __init__(self, serialport):
        LocoBufferCommunicator.__init__(self)
        self.ser = serialport
        msg = LocoLib.powerOn()
        self.write(msg)

### Function: read
### Purpose: read the serial port and forward data

    def readLoop(self):
        while self.alive:
            self._write_lock.acquire()
            try:
                #print "read loco"
                b = self.ser.read(1)
                #print "done read loco"
                if b != '':
                    curByte = h.hexByteToBinStr(b)
                    if (curByte[:1] == '1'): # if it's an opcode we want to begin parsing
                        msgStr = b
                        msgLen, curByte = h.getMsgLen(self.ser, curByte) 
                        msgStr += curByte
                        for i in range(msgLen):
                            #print "read 2 loco"
                            curByte = self.ser.read(1)
                            #print "done read 2 loco"
                            msgStr += curByte
                        # add msg to a buffer and notify observers
                        num = len(msgStr)
                        self.dataBuffer.addData(chr(num) + "\x00" + msgStr)
                        print "added data ", LocoLib.convertToStandardMessage(chr(num) + "\x00" + msgStr)
                        # notification is free with the condition variable
            except Exception as inst:
                print inst
                #sys.stderr.write("ERROR: %s" % inst)
                #sys.stderr.write("Exiting Read Loop...\n")
                #self.alive = False
                #self.doCleanup()
            finally:
                self._write_lock.release()

    def write(self, data):
        self._write_lock.acquire()
        try:
            num = ord(data[0])
            #print "Sending", repr(data[2:])
            self.ser.write(data[2:])
            #print "done send"
            #self.ser.flush()
            bounceBack = self.ser.read(num)
            if bounceBack != None and len(bounceBack) > 0 and bounceBack != data[2:]:
                print "WHAT THE!!!!!", LocoLib.convertToStandardMessage(chr(len(bounceBack)) + "\x00" + bounceBack)
        except Exception as inst:
            print inst
        finally:
            self._write_lock.release()

### Class: SimulatorInterface
### Purpose: Read from a train simulator over a socket

class SimulatorInterface(LocoBufferCommunicator):

    def __init__(self, socket):
        LocoBufferCommunicator.__init__(self)
        self.socket = socket
    
    def readLoop(self):
        self.socket.setblocking(0)
        self.socket.settimeout(1)
        while self.alive:
            try:
                curByte = None
                data = self.socket.recv(1)
                if len(data) > 0: 
                    curByte = h.hexByteToBinStr(data)
                if curByte is None:
                    None
                elif (curByte[:1] == '1'): # if it's an opcode we want to begin parsing
                    msgStr = data
                    msgLen, curByte = h.getMsgLen(self.socket, curByte)
                    msgStr += curByte
                    for i in range(1, msgLen):
                        curByte = self.socket.recv(1)
                        msgStr += curByte
                        # add msg to a buffer and notify observers
                    msgStr = "\x0e\x00" + msgStr
                    self.dataBuffer.addData(msgStr)
                    print "Added: ", repr(msgStr), " from the LocoBuffer\n"
                    # notification is free with the condition variable
            except socket.timeout:
                None # Just continue looping
            except Exception as inst:
                print inst
            except socket.error:
                print "Exiting read loop...\n"
                self.alive = False
                self.doCleanup()
    
    def write(self, data):
        self._write_lock.acquire()
        try:
            self.socket.send(data)
        finally:
            self._write_lock.release()

### Class: BaseObserver
### Purpose: Implement basic functionality to - 1. Send data from the LocoBuffer to the socket
###                                             2. Send data from the socket to the LocoBuffer and other observers
###          The details of this are defined in subclasses

class BaseObserver:

    def __init__(self, lbcom, socket):
        self.alive = True
        self.lbcom = lbcom                          # link facilitating forwarding tcp data as "virtual" LocoBuffer data
        self.socket = socket                        # socket
        self.dataRef = lbcom.dataBuffer             # shared resource where the data to copy is
        self.myID = self.dataRef.registerObserver() # obtain an observer id to get data
        self._write_lock = threading.Lock()         # Lock for tcp writing

### Function: observe
### Purpose: Handle incoming LocoBuffer data

    def observer(self):
        while self.alive:
            data = self.dataRef.getDataForObserver(self.myID)
            print "Throttle recieved: ", repr(data)
            if not self.alive: return
            self._write_lock.acquire()
            try:
                self.socket.sendall(data)
            except socket.error:
                None
            finally:
                    self._write_lock.release()

### Function: tcpreader
### Purpose: Reads socket and forwards messages to serial port and other observers

    def tcpReader(self):
        self.socket.setblocking(0)
        self.socket.settimeout(1)
        while self.alive:
            try:
                data = self.socket.recv(2)
                if data is not None and len(data) > 0:
                    num = ord(data[0])
                    stuff = self.socket.recv(num)
                    if stuff is not None:
                        data += stuff
                        self.forwardTCPData(data)
            except socket.timeout:
                None
            except socket.error, msg:
                sys.stderr.write('Error: %s\n' % msg)
                break
        self.alive = False
        self.observerThread.join()

### Function: forwardTCPData
### Purpose: What the observer does with incoming socket data

    def forwardTCPData(self, data):
        # Let the derived classes handle this
        return

### Function: shortcut
### Purpose: Begin multithreading for this object

    def shortcut(self):
        self.alive = True
        self.observerThread = threading.Thread(target=self.observer)
        self.observerThread.start()
        self.tcpThread = threading.Thread(target=self.tcpReader)
        self.tcpThread.start()

### Function: closeObserver
### Purpose: Cause the read loop to exit

    def killObserver(self):
        self.alive = False

### Class: Throttle
### Purpose: Provides behaviour of a standard throttle in multiple run-modes

class Throttle(BaseObserver):

    def __init__(self, lbcom, socket):
        BaseObserver.__init__(self, lbcom, socket)
        if lbcom.filter is not None:
            self.dataRef.unregisterObserver(self.myID)
            self.dataRef = lbcom.filter.filteredData
            self.myID = self.dataRef.registerObserver()

    def forwardTCPData(self, data):
        if self.lbcom.filter is not None:
            print "Added: ", repr(data), " from filtered throttle to filter"
            self.lbcom.filter.dataRef.addData(data)
        else:
            if data[0] != "\x00":
                print "Added: ", repr(data), " from unfiltered Throttle"
                self.lbcom.dataBuffer.addData(data)
                self.lbcom.write(data)

### Class: Interceptor(BaseObserver):
### Purpose: Provides data filtering for train control systems such as PyRail or AdaRail

class Interceptor(BaseObserver):

    def __init__(self, lbcom, socket):
        BaseObserver.__init__(self, lbcom, socket)
        self.cv = threading.Condition()
        self.filteredData = SharedDataBuffer(self.cv)

    def forwardTCPData(self, data):
        self.filteredData.addData(data)
        msg = LocoLib.convertToStandardMessage(data)
        print "Added: ", msg, " from filtered system"
        if data[2] != "\x00":
            print "filter send", msg, "to locobuffer"
            self.lbcom.write(data)

if __name__ == '__main__':
    import optparse

    optparser = optparse.OptionParser(
        usage = "%prog [options] [port [baudrate]]",
        description = "TCP server interface to the LocoBuffer.")

    group = optparse.OptionGroup(optparser, "Run Mode", "Standard or Simulated")
    optparser.add_option_group(group)

    group.add_option("-m", "--mode", dest = "mode", action = "store", type = "int", help = "-m <0 or 1>, default: %default", default = 0) 

    group = optparse.OptionGroup(optparser, "Serial Port", "Serial port settings")
    optparser.add_option_group(group)

    group.add_option("-p", "--port", dest = "port", help = "-p <number or device name>", default = None)
    group.add_option("-b", "--baud", dest = "baudrate", action = "store", type = "int", help = "set baud rate, default: %default", default = 57600)
    
    group = optparse.OptionGroup(optparser, "Network settings", "Network configuration")
    optparser.add_option_group(group)

    group.add_option("-P", "--localport", dest = "local_port", action = "store", type = "int", help = "local TCP port", default = 7245)
    group.add_option("-H", "--host", dest = "host", help = "host of the simulator", default='localhost')

    group = optparse.OptionGroup(optparser, "PyRail Settings", "Add filter first")
    optparser.add_option("-f", "--filtered", dest = "filtered", action = "store", type = "int", help = "first connection recieved is filtered", default = 0)

    (options, args) = optparser.parse_args()

    port = options.port
    baudrate = options.baudrate
    if args:
        if options.port is not None:
            optparser.error("no args allowed when --port is given")
        port = args.pop(0)
        if args:
            try:
                baudrate = int(args[0])
            except ValueError:
                optparser.error("baud rate must be a number, not %r" % args[0])
            args.pop(0)
        if args:
            optparser.error("too many args")
    else:
        if port is None: port = 0

    locoBufferCom = None
    lbcThread = None
    sys.stderr.write("--- LocoBuffer TCP Server --- type Ctrl-C or BREAK to quit\n")
    if options.mode > 0: # Simulated Mode
        port = int(port)
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sys.stderr.write("--- Simulating on host: %s at port: %d\n" % (options.host, port))
        try:
            sock.connect((options.host, port))
            locoBufferCom = SimulatorInterface(sock)
        except Exception as inst:
            sys.stderr.write("Could not open tcp connection: %s" % inst)
            sys.exit(1)

    else: # Standard Mode
        ser = serial.Serial()
        ser.bytesize = serial.EIGHTBITS
        ser.stopbits = serial.STOPBITS_ONE
        ser.port     = port
        ser.baudrate = baudrate
        ser.parity   = serial.PARITY_NONE
        ser.rtscts   = True
        ser.xonxoff  = False
        ser.dsrdtr = True
        ser.timeout  = 1 
        #ser.writeTimeout = 0
        sys.stderr.write("--- SP: %s BR: %s LP: %s ---\n" % (ser.portstr, ser.baudrate, options.local_port))

        try:
            ser.open()
            locoBufferCom = SerialInterface(ser)
        except serial.SerialException, e:
            sys.stderr.write("Could not open serial port %s: %s\n" % (ser.portstr, e))
            sys.exit(1)

    if locoBufferCom is not None:
        locoBufferCom.closePort = options.local_port
        lbcThread = threading.Thread(target=locoBufferCom.readLoop)
        lbcThread.start()

    srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    srv.bind( ('', options.local_port) )
    srv.listen(1)
    allObservers = []
    filtered = options.filtered
    while locoBufferCom.alive:
        try:
            sys.stderr.write("Waiting for connection on %s...\n" % options.local_port)
            conn, addr = srv.accept()
            sys.stderr.write('Connected by %s\n' % (addr,))
            t = None
            if filtered > 0:
                # Add an interceptor
                sys.stderr.write('Added as Filter\n')
                t = Interceptor(locoBufferCom, conn)
                locoBufferCom.filter = t
                filtered = 0
            else:
                # Add throttle
                sys.stderr.write('Added as Throttle\n')
                t = Throttle(locoBufferCom, conn)
            if t is not None:
                tmpThread = threading.Thread(target=t.shortcut)
                tmpThread.start()
                allObservers.append(t)
        except KeyboardInterrupt:
            locoBufferCom.alive = False
            break
        except socket.error, msg:
            sys.stderr.write('ERROR: %s\n' % msg)
    # Close all connections and exit
    sys.stderr.write("\nConnection to LocoBuffer Closed.\nJoining with LBC...")
    lbcThread.join()
    sys.stderr.write("done\n")
    for obs in allObservers:
        obs.killObserver()
    locoBufferCom.dataBuffer.addData("BOGUSDATA")
    for obs in allObservers:
        sys.stderr.write("Joining observer...")
        obs.tcpThread.join()
        sys.stderr.write("done\n")
    sys.stderr.write('\n--- exit ---\n')
