### LocoLogic.py
### File that contains the logic of the system
### logic derives from a generic FSM and interchangeable states

import threading
from LocoLib import *
from collections import deque
import time
import datetime as dt

class DelayedEvent:

    def __init__(self, timeval, func):
        self.time = timeval
        self.func = func
        self.valid = True
        self.validLock = threading.Lock()
        
    def runThread(self):
        #print "event queued"
        time.sleep(self.time)
        #print "do event"
        self.validLock.acquire()
        if self.valid:
            self.func()
        self.validLock.release()

    def cancel(self):
        self.validLock.acquire()
        self.valid = False
        self.validLock.release()

    def startTimer(self):
        t = threading.Thread(target=self.runThread)
        t.start()

class BaseState:

    def __init__(self, fsm):
        self.fsm = fsm

    def enterState(self):
        return

    def exitState(self):
        return

    def handleMsg(self, msg):
        return

class FiniteStateMachine:

    def __init__(self):
        self.object = None
        self.state = None
        self.stateStack = deque()

    def handleMsg(self, msg):
        if self.state is not None:
            self.state.handleMsg(msg)

    def changeToState(self, state):
        if self.state is not None:
            self.state.exitState()
        self.state = state
        if state is not None:
            self.state.enterState()

    def pushState(self, state):
        if self.state is not None:
            self.stateStack.appendleft(self.state)
        self.state = state
        if state is not None:
            self.state.enterState()

    def popState(self):
        try:
            if self.state is not None:
                self.state.exitState()
                self.state = self.stateStack.pop()
        except IndexError:
            self.state = None

### Sensor States

class SensorStateOpen(BaseState):

    def __init__(self):
        BaseState.__init__(self)

    def __init__(self, fsm):
        BaseState.__init__(self, fsm)

    def enterState(self):
        self.fsm.object.state = "open"

    def handleMsg(self, msg):
        if msg.command == "OPC_INPUT_REP":
            self.fsm.changeToState(SensorStateClosed(self.fsm))
            self.fsm.object.lm.identifyTrain(msg.sensor)

class SensorStateClosed(BaseState):

    #def __init__(self):
    #   BaseState.__init__(self)
    #  self.nextTime = 0

    def __init__(self, fsm):
        BaseState.__init__(self, fsm)
        self.nextTime = 0

    def enterState(self):
        self.fsm.object.state = "closed"
        self.nextTime = dt.datetime.now() + dt.timedelta(0, 1, 0)

    def handleMsg(self, msg):
        if msg.command == "OPC_INPUT_REP":
            if dt.datetime.now() > self.nextTime:
                self.fsm.changeToState(SensorStateOpen(self.fsm))

### Switch States

class BaseSwitchState(BaseState):

    def __init__(self, fsm):
        BaseState.__init__(self, fsm)
        self.name = ""
    
    def getNameNumber(self):
        if self.name == "closed":
            return 0
        elif self.name == "thrown":
            return 1
        elif self.name == "beginclose":
            return 2
        elif self.name == "beginthrow":
            return 3
        elif self.name == "error":
            return 4
    
    def enterState(self):
        self.fsm.object.lm.cmdQM.locoTransmitter.send(LocoLib.putSwitchState(PUT_SWITCH_STATE('PUT_SWITCH_STATE', self.fsm.object.id, self.getNameNumber())))

class SwitchStateClosed(BaseSwitchState):

    def __init__(self, fsm):
        BaseSwitchState.__init__(self, fsm)
        self.name = "closed"

    def handleMsg(self, msg):
        if msg.command == "OPC_SW_REQ" and msg.dir == "0":
            if self.fsm.object.lm.canMoveSwitch(self.fsm.object):
                self.fsm.object.lm.doMoveSwitch(self.fsm.object, msg.dir)
                self.fsm.changeToState(SwitchStateBeginThrow(self.fsm))

    def enterState(self):
        #return putSwitchState
        BaseSwitchState.enterState(self)
        print "switch closed"
        for sec in self.fsm.object.blockWhenThrowing:
            sec.decBlockCount()
    
class SwitchStateThrown(BaseSwitchState):
        
    def __init__(self, fsm):
        BaseSwitchState.__init__(self, fsm)
        self.name = "thrown"
        
    def handleMsg(self, msg):
        if msg.command == "OPC_SW_REQ" and msg.dir == "1":
            if self.fsm.object.lm.canMoveSwitch(self.fsm.object):
                self.fsm.object.lm.doMoveSwitch(self.fsm.object, msg.dir)
                self.fsm.changeToState(SwitchStateBeginClose(self.fsm))
    
    def enterState(self):
        # return putSwitchState
        BaseSwitchState.enterState(self)
        print "switch thrown"
        for sec in self.fsm.object.blockWhenClosing:
            sec.decBlockCount()

class SwitchStateBeginClose(BaseSwitchState):
        
    def __init__(self, fsm):
        BaseSwitchState.__init__(self, fsm)
        self.name = "beginclose"

    def handleMsg(self, msg):
        if msg.command == "OPC_SW_REQ" and msg.dir == "0": # throw 
            if self.fsm.object.lm.canMoveSwitch(self.fsm.object):
                for sec in self.fsm.object.blockWhenClosing:
                    sec.incBlockCount()
                self.fsm.object.lm.doMoveSwitch(self.fsm.object, msg.dir)
                self.fsm.changeToState(SwitchStateBeginThrow(self.fsm))
        elif msg.command == "OPC_SW_REP" and msg.hl == "1":
            self.fsm.changeToState(SwitchStateClosed(self.fsm))

    def enterState(self):
        print "switch begin close"
        BaseSwitchState.enterState(self)
        for sec in self.fsm.object.blockWhenClosing:
            sec.incBlockCount()

class SwitchStateBeginThrow(BaseSwitchState):
        
    def __init__(self, fsm):
        BaseSwitchState.__init__(self, fsm)
        self.name = "beginthrow"
        
    def handleMsg(self, msg):
        if msg.command == "OPC_SW_REQ" and msg.dir == "1": # close 
            if self.fsm.object.lm.canMoveSwitch(self.fsm.object):
                for sec in self.fsm.object.blockWhenThrowing:
                    sec.incBlockCount()
                self.fsm.object.lm.doMoveSwitch(self.fsm.object, msg.dir)
                self.fsm.changeToState(SwitchStateBeginClose(self.fsm))
        elif msg.command == "OPC_SW_REP" and msg.hl == "0":
            self.fsm.changeToState(SwitchStateThrown(self.fsm))
    
    def enterState(self):
        # return putSwitchState
        BaseSwitchState.enterState(self)
        print "switch begin throw"
        for sec in self.fsm.object.blockWhenThrowing:
            sec.incBlockCount()        

### Section States

class BaseSectionState(BaseState):

    def __init__(self, fsm):
        BaseState.__init__(self, fsm)
        self.name = ""
        
    def enterState(self):
        self.fsm.object.lm.cmdQM.locoTransmitter.send(LocoLib.putSectionState(PUT_SECTION_STATE('PUT_SECTION_STATE', self.fsm.object.id, self.getNameNumber())))
        
    def getNameNumber(self):
        if self.name == "free":
            return 0
        elif self.name == "reserved":
            return 1
        elif self.name == "occupied":
            return 2
        elif self.name == "blocked":
            return 3

class SectionStateFree(BaseSectionState):
        
    def __init__(self, fsm):
        BaseSectionState.__init__(self, fsm)
        self.name = "free"

    def enterState(self):
        smsg = MSG_TRY_MOVE_AGAIN("MSG_TRY_MOVE_AGAIN")
        self.fsm.object.lm.cmdQM.queue.addMsg(smsg)
        BaseSectionState.enterState(self)

    #def handleMsg(self, msg):
    #    if msg.command == "MSG_FRONT_SENSOR_FIRED":
    #        self.fsm.changeToState(SectionStateReserved(self.fsm))
        

class SectionStateReserved(BaseSectionState):
        
    def __init__(self, fsm):
        BaseSectionState.__init__(self, fsm)  
        self.name = "reserved"        
        
    #def handleMsg(self, msg):
    #    if msg.command == "MSG_FRONT_SENSOR_FIRED":
    #        self.fsm.changeToState(SectionStateOccupied(self.fsm))
        
    def enterState(self):
        print "in reserved state"
        for sec in self.fsm.object.blockList:
            sec.incBlockCount()
        BaseSectionState.enterState(self)

class SectionStateOccupied(BaseSectionState):
        
    def __init__(self, fsm):
        BaseSectionState.__init__(self, fsm)
        self.name = "occupied"
        
    #def handleMsg(self, msg):
    #    if msg.command == "MSG_BACK_SENSOR_FIRED":
    #        self.fsm.changeToState(SectionStateFree(self.fsm))
    
    def enterState(self):
        BaseSectionState.enterState(self)
    
    def exitState(self):
        for sec in self.fsm.object.blockList:
            sec.decBlockCount()
        #smsg = MSG_TRY_MOVE_AGAIN("MSG_TRY_MOVE_AGAIN")
        #self.fsm.object.lm.cmdQM.queue.addMsg(smsg)

class SectionStateBlocked(BaseSectionState):

    def __init__(self, fsm):
        BaseSectionState.__init__(self, fsm)
        self.name = "blocked"
    
    def enterState(self):
        BaseSectionState.enterState(self)
        
    def exitState(self):
        smsg = MSG_TRY_MOVE_AGAIN("MSG_TRY_MOVE_AGAIN")
        self.fsm.object.lm.cmdQM.queue.addMsg(smsg)

### Train States

class BaseTrainState(BaseState):
    
    def __init__(self, fsm):
        BaseState.__init__(self, fsm)
        self.name = ""
        
    def handleMsg(self, msg):
        if msg.command == "MSG_SENSOR_ERROR":
            self.fsm.changeToState(TrainStateError(self.fsm))
        elif msg.command == "OPC_LOCO_SND":
            msg.slot = self.fsm.object.pSlot
            self.fsm.object.lm.cmdQM.locoTransmitter.send(msg)
        elif msg.command == "OPC_LOCO_DIRF":
            if (msg.dir == self.fsm.object.dir):
                newMsg = OPC_LOCO_DIRF('OPC_LOCO_DIRF', self.fsm.object.pSlot, msg.dir, msg.lights, msg.horn, msg.bell)
                self.fsm.object.lm.cmdQM.locoTransmitter.send(LocoLib.changeDirf(newMsg))
            self.fsm.object.lights = msg.lights
            self.fsm.object.horn = msg.horn
            self.fsm.object.bell = msg.bell
            self.fsm.object.dir = msg.dir
        elif msg.command == "MSG_BACK_SENSOR_FIRED":
            # update location
            self.fsm.object.lm.advanceBackOfTrain(self.fsm.object.vAddr)
            self.fsm.object.lm.cmdQM.locoTransmitter.send(LocoLib.putTrainPosition(PUT_TRAIN_POSITION('PUT_TRAIN_POSITION', self.fsm.object.vSlot, self.fsm.object.lm.getTrainLocationList(self.fsm.object.vAddr))))
        elif msg.command == "MSG_FRONT_SENSOR_FIRED":
            # update location
            self.fsm.object.lm.advanceFrontOfTrain(self.fsm.object.vAddr)
            self.fsm.object.lm.cmdQM.locoTransmitter.send(LocoLib.putTrainPosition(PUT_TRAIN_POSITION('PUT_TRAIN_POSITION', self.fsm.object.vSlot, self.fsm.object.lm.getTrainLocationList(self.fsm.object.vAddr))))
            # make reservation
            if (not self.fsm.object.lm.reserveNext(self.fsm.object.vAddr)):
                self.fsm.changeToState(TrainStateBeginWait(self.fsm))
                
    def enterState(self):
        self.fsm.object.lm.cmdQM.locoTransmitter.send(LocoLib.putTrainState(PUT_TRAIN_STATE('PUT_TRAIN_STATE', self.fsm.object.vSlot, self.getNameNumber())))
        
    def getNameNumber(self):
        if self.name == "moving":
            return 0
        elif self.name == "wait":
            return 1
        elif self.name == "halt":
            return 2
        elif self.name == "error":
            return 3
        elif self.name == "bcd":
            return 4
        elif self.name == "bw":
            return 5
        elif self.name == "bh":
            return 6

class TrainStateMoving(BaseTrainState):

    def __init__(self, fsm):
        BaseTrainState.__init__(self, fsm)
        self.name = "moving"

    def enterState(self):
        # Send speed msg
        BaseTrainState.enterState(self)
        print "enterState: train state moving"
        spdmsg = LocoLib.changeSpeed(OPC_LOCO_SPD('OPC_LOCO_SPD', self.fsm.object.pSlot, self.fsm.object.speed))
        self.fsm.object.lm.cmdQM.locoTransmitter.send(spdmsg)

    def exitState(self):
        # send speed 0 msg
        spdmsg = LocoLib.changeSpeed(OPC_LOCO_SPD('OPC_LOCO_SPD', self.fsm.object.pSlot, 0))
        self.fsm.object.lm.cmdQM.locoTransmitter.send(spdmsg)
        self.fsm.object.lm.releaseReservation(self.fsm.object.vAddr)

    def handleMsg(self, msg):
        if msg.command == "OPC_LOCO_SPD":
            if msg.speed == 0:
                self.fsm.changeToState(TrainStateBeginHalt(self.fsm))
            elif msg.speed > 0:
                # change speed
                self.fsm.object.speed = msg.speed
                # send message
                spdmsg = LocoLib.changeSpeed(OPC_LOCO_SPD('OPC_LOCO_SPD', self.fsm.object.pSlot, msg.speed))
                self.fsm.object.lm.cmdQM.locoTransmitter.send(spdmsg)
        elif msg.command == "OPC_LOCO_DIRF":
            if (msg.dir != self.fsm.object.dir):
                self.fsm.changeToState(TrainStateBeginChangeDirection(self.fsm))
            BaseTrainState.handleMsg(self, msg)
        elif msg.command == "MSG_LOSE_RESERVATION":
            self.fsm.changeToState(TrainStateBeginWait(self.fsm))
        else:
            BaseTrainState.handleMsg(self, msg)

class TrainStateWait(BaseTrainState):

    def __init__(self, fsm):
        BaseTrainState.__init__(self, fsm)
        self.name = "wait"

    def enterState(self):
        BaseTrainState.enterState(self)
        # release reservation -- done in tmoving exit
        print "enterState: train state wait", self.fsm.object.vAddr
        #self.fsm.object.lm.releaseReservation(self.fsm.object.vAddr)

    def handleMsg(self, msg):
        if msg.command == "OPC_LOCO_SPD":
            if msg.speed == 0:
                self.fsm.changeToState(TrainStateHalt(self.fsm))
            elif msg.speed > 0:
                # change speed of train - no messages
                self.fsm.object.speed = msg.speed
        elif msg.command == "OPC_LOCO_DIRF":
            if (msg.dir != self.fsm.object.dir):
                # tell layman new dir
                self.fsm.object.lm.switchTrainDirection(self.fsm.object.vAddr)
                # send dirf
                msg = OPC_LOCO_DIRF('OPC_LOCO_DIRF', self.fsm.object.pSlot, msg.dir, msg.lights, msg.horn, msg.bell)
                self.fsm.object.lm.cmdQM.locoTransmitter.send(LocoLib.changeDirf(msg))
                # make reservation
                gotRes = self.fsm.object.lm.reserveNext(self.fsm.object.vAddr)
                if (gotRes and self.fsm.object.speed > 0):
                    self.fsm.changeToState(TrainStateMoving(self.fsm))
                else:
                    self.fsm.changeToState(TrainStateWait(self.fsm))
            else:
                # record vals
                self.fsm.object.lm.cmdQM.locoTransmitter.send(LocoLib.changeDirf(msg))
            BaseTrainState.handleMsg(self, msg)
        elif msg.command == "MSG_FRONT_SENSOR_FIRED":
            self.fsm.changeToState(TrainStateError(self.fsm))
        elif msg.command == "MSG_TRY_MOVE_AGAIN":
            # make reservation
            print "in tma for trainStateWait ", self.fsm.object.vAddr
            if (self.fsm.object.lm.reserveNext(self.fsm.object.vAddr)):
                self.fsm.changeToState(TrainStateMoving(self.fsm))
        else:
            BaseTrainState.handleMsg(self, msg)

class TrainStateHalt(BaseTrainState):

    def __init__(self, fsm):
        BaseTrainState.__init__(self, fsm)
        self.name = "halt"

    def enterState(self):
        BaseTrainState.enterState(self)
        print "enterState: train state halt"
        # release res
        #if self.fsm.object.lm is not None:
        #    self.fsm.object.lm.releaseReservation(self.fsm.object.vAddr)

    def handleMsg(self, msg):
        if msg.command == "OPC_LOCO_SPD":
            if msg.speed > 0:
                self.fsm.object.speed = msg.speed
                #make reservation
                if (self.fsm.object.lm.reserveNext(self.fsm.object.vAddr)):
                    self.fsm.changeToState(TrainStateMoving(self.fsm))
                else:
                    self.fsm.changeToState(TrainStateWait(self.fsm))
        elif msg.command == "OPC_LOCO_DIRF":
            if (self.fsm.object.dir != msg.dir): # True = different direction
                # tell layman new dir
                self.fsm.object.lm.switchTrainDirection(self.fsm.object.vAddr)
                # send dirf msg
                self.fsm.object.lm.cmdQM.locoTransmitter.send(LocoLib.changeDirf(msg))
            else:
                # record vals
                # send msg back
                self.fsm.object.lm.cmdQM.locoTransmitter.send(LocoLib.changeDirf(msg))
            BaseTrainState.handleMsg(self, msg)
        elif msg.command == "MSG_FRONT_SENSOR_FIRED":
            self.fsm.changeToState(TrainStateError(self.fsm))
        elif msg.command == "MSG_BACK_SENSOR_FIRED":
            self.fsm.changeToState(TrainStateError(self.fsm))
        else:
            BaseTrainState.handleMsg(self, msg)

class TrainStateBeginChangeDirection(BaseTrainState):

    def __init__(self, fsm):
        BaseTrainState.__init__(self, fsm)
        self.name = "bcd"
        self.initialDirection = self.fsm.object.dir
        self.timer = DelayedEvent(3, self.onTimer)
    
    def enterState(self):
        BaseTrainState.enterState(self)
        self.timer.startTimer()
        
    def handleMsg(self, msg):
        if msg.command == "OPC_LOCO_DIRF":
            if (self.fsm.object.dir != msg.dir): # True = different direction
                self.fsm.object.dir = msg.dir
            else:
                self.fsm.object.lm.cmdQM.locoTransmitter.send(LocoLib.changeDirf(msg))
            BaseTrainState.handleMsg(self, msg)
        else:
            BaseTrainState.handleMsg(self, msg)
        
    def onTimer(self):
        # tell layman new dir
        if (self.fsm.object.dir != self.initialDirection):
            self.fsm.object.lm.switchTrainDirection(self.fsm.object.vAddr)
        # send dirf
        self.fsm.object.lm.cmdQM.locoTransmitter.send(LocoLib.changeDirf(OPC_LOCO_DIRF("OPC_LOCO_DIRF", self.fsm.object.pSlot, self.fsm.object.dir, self.fsm.object.lights, self.fsm.object.horn, self.fsm.object.bell)))
        # make reservation
        if (self.fsm.object.speed > 0 and self.fsm.object.lm.reserveNext(self.fsm.object.vAddr)):
            self.fsm.changeToState(TrainStateMoving(self.fsm))
        elif (self.fsm.object.speed == 0):
            self.fsm.changeToState(TrainStateHalt(self.fsm))
        else:
            self.fsm.changeToState(TrainStateWait(self.fsm))

class TrainStateBeginWait(BaseTrainState):

    def __init__(self, fsm):
        BaseTrainState.__init__(self, fsm)
        self.name = "bw"
        self.timer = DelayedEvent(3, self.onTimer)

    def enterState(self):
        BaseTrainState.enterState(self)
        print "enterState: train state begin wait"
        self.timer.startTimer()
        "sending stop from begin wait"
        #spdmsg = LocoLib.changeSpeed(OPC_LOCO_SPD('OPC_LOCO_SPD', self.fsm.object.pSlot, 0))
        #print "speed message", repr(spdmsg)
        #self.fsm.object.lm.cmdQM.locoTransmitter.send(spdmsg)
        #self.fsm.object.lm.releaseReservation(self.fsm.object.vAddr)

    def handleMsg(self, msg):
        if msg.command == "OPC_LOCO_SPD":
            if msg.speed == 0:
                self.timer.cancel()
                self.fsm.changeToState(TrainStateBeginHalt(self.fsm))
            elif msg.speed > 0:
                # set speed - no messages
                self.fsm.object.speed = msg.speed
        elif msg.command == "OPC_LOCO_DIRF":
            if (self.fsm.object.dir != msg.dir): # True = different direction
                self.fsm.changeToState(TrainStateBeginChangeDirection(self.fsm))
            else:
                self.fsm.object.lm.cmdQM.locoTransmitter.send(LocoLib.changeDirf(msg))
            BaseTrainState.handleMsg(self, msg)
        elif msg.command == "MSG_TRY_MOVE_AGAIN":
            # make reservation
            #print "TRY MOVE AGAIN BEGIN WAIT", self.fsm.object.vAddr
            if (self.fsm.object.lm.reserveNext(self.fsm.object.vAddr)):
                self.timer.cancel()
                self.fsm.changeToState(TrainStateMoving(self.fsm))
        else:
            BaseTrainState.handleMsg(self, msg)
    
    def onTimer(self):
        self.fsm.changeToState(TrainStateWait(self.fsm))

class TrainStateBeginHalt(BaseTrainState):

    def __init__(self, fsm):
        BaseTrainState.__init__(self, fsm)
        self.name = "bh"
    
    def enterState(self):
        BaseTrainState.enterState(self)
        print "enterState: train state begin halt"
        self.timer = DelayedEvent(3, self.onTimer)

    def handleMsg(self, msg):
        if msg.command == "OPC_LOCO_SPD":
            if msg.speed > 0:
                # set speed - no messages
                self.fsm.object.speed = msg.speed
                # make reservation
                if (self.fsm.object.lm.reserveNext(self.fsm.object.vAddr)):
                    self.fsm.changeToState(TrainStateMoving(self.fsm))
                else:
                    self.fsm.changeToState(TrainStateBeginWait(self.fsm))
        elif msg.command == "OPC_LOCO_DIRF":
            if (self.fsm.object.dir != msg.dir): # True = different direction
                self.fsm.changeToState(TrainStateBeginChangeDirection(self.fsm))
            else:
                # record vals
                self.fsm.object.lm.cmdQM.locoTransmitter.send(LocoLib.changeDirf(msg))
            BaseTrainState.handleMsg(self, msg)
        else:
            BaseTrainState.handleMsg(self, msg)
    
    def onTimer(self):
        self.fsm.changeToState(TrainStateHalt(self.fsm))

class TrainStateError(BaseTrainState):

    def __init__(self, fsm):
        BaseState.__init__(self, fsm)
        self.name = "error"

    def enterState(self):
        BaseTrainState.enterState(self)

### LayoutManager states -- only one so far but I like consistency

class LayoutManagerStateActive(BaseState):

    def __init__(self, fsm):
        BaseState.__init__(self, fsm)
    
    def handleMsg(self, msg):
        try:
            if msg.command == "OPC_SW_REQ" or msg.command == "OPC_SW_REP":
                self.fsm.object.switches[msg.switchNum].fsm.handleMsg(msg)
            elif msg.command == "OPC_INPUT_REP":
                self.fsm.object.sensors[msg.sensor].fsm.handleMsg(msg)
        except Exception as inst:
            print inst
