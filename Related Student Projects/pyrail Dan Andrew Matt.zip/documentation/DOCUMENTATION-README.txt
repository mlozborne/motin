OriginalDesign.odt is the original design document.

The ONLY design modifications are included in ModifiedDesign.png.
Also, in this diagram, some functions for common classes such as
the layout manager are ommitted.  All logic and message pathways
are analagous to the original design after accounting for the
modifications with a mapping between groups of objects.

Throttle design is essentially the standard GUI event loop model.
Extra design notes/differences are included in SimpleThrottle.odp.

XML specification is SLIGHTLY different and can be seen in the
LayoutSpec.dtd file and verified against a layout file online.
