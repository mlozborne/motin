﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Load_Server
{
    public partial class EditWindow : Form
    {
        string pictureFileName;
        string layoutFileName;
        LayoutRecord arr;
        Bitmap image;

        public EditWindow()
        {
            InitializeComponent();
            arr = Globals.GlobalTempLayoutRecord;
            txtName.Text = arr.Name;
            txtLayoutFile.Text = arr.layoutFile;
            txtIPAddress.Text = arr.IPAddress;
            txtPortNum.Text = arr.Port;
            image = new Bitmap(arr.pictureFilename);
            picBox.Image = image;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            //Create new record and save it
            arr.Name = txtName.Text;
            arr.IPAddress = txtIPAddress.Text;
            arr.Port = txtPortNum.Text;
            arr.pictureFilename = pictureFileName;
            arr.layoutFile = layoutFileName;
            Globals.GlobalTempLayoutRecord = arr;
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            //Close dialog without saving anything
            this.Close();
        }

        private void picBox_Click(object sender, EventArgs e)
        {
            //Open up picture dialog box
            OpenFileDialog aDlg = new OpenFileDialog();
            aDlg.FileName = arr.pictureFilename;
            aDlg.Title = "Image of layout";
            aDlg.Filter = "JPG Files(*.jpg)" + "|*.jpg;|" + "jpg (*.jpg)|*.jpg";
            if (aDlg.ShowDialog() == DialogResult.OK)
            {
                pictureFileName = aDlg.FileName;
                image = new Bitmap(arr.pictureFilename);
                picBox.Image = image;
            }
        }

        private void txtLayoutFile_Click(object sender, EventArgs e)
        {
            OpenFileDialog aDlg = new OpenFileDialog();
            aDlg.FileName = arr.layoutFile;
            aDlg.Title = "Layout Description File";
            aDlg.Filter = "XML Files(*.xml)" + "|*.xml|" + "xml(*.xml)|*.xml";
            if (aDlg.ShowDialog() == DialogResult.OK)
            {
                layoutFileName = aDlg.FileName;
            }
            txtLayoutFile.Text = layoutFileName;
        }
    }
}
