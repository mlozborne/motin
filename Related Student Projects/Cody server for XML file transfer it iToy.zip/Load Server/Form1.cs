﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net.Sockets;
using System.Net;
using System.IO;
using System.Threading;

//http://stackoverflow.com/questions/5421495/file-transfer-using-sockets-and-multiple-clients

namespace Load_Server
{
    

    public partial class Form1 : Form
    {
        int currentLayoutDisplayed = 0;
        int totalLayouts = 0;
        Bitmap image;
        LayoutRecord[] arr;
        LayoutRecord currentLayout;
        SaveData data;
        Worker workerObject;
        Thread workerThread;

        public Form1()
        {
            InitializeComponent();
            txtPort.Text = Properties.Settings.Default.PortNumber.ToString();
            btnLast.Enabled = false;
            btnNext.Enabled = false;
            data = new SaveData();

            //setup threads
            workerObject = new Worker();
            workerThread = new Thread(workerObject.DoWork);

            //open saved data file
            int error = data.ProgramOpenData();
            if (error == 1)
            {
                //load data
                currentLayoutDisplayed = data.saveData.currentLayoutDisplayed;
                totalLayouts = data.saveData.totalLayouts;
                image = data.saveData.image;
                picBox.Image = image;
                arr = data.saveData.arr;
                currentLayout = data.saveData.currentLayout;
                lblName.Text = currentLayout.Name;
                lblFile.Text = currentLayout.layoutFile;
                lblAddress.Text = currentLayout.IPAddress;
                lblport.Text = currentLayout.Port;
                Globals.GlobalLayoutArr = data.saveData.globalArr;
                Globals.GlobalTotalLayouts = data.saveData.globalTotalLayouts;
                if (currentLayoutDisplayed == 0 && totalLayouts > 1)
                {
                    btnNext.Enabled = true;
                }
                if (currentLayoutDisplayed + 1 == totalLayouts)
                {
                    btnNext.Enabled = false;
                    btnLast.Enabled = true;
                }
            }
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void btnLast_Click(object sender, EventArgs e)
        {
            //display last layout
            currentLayoutDisplayed--;
            currentLayout = arr[currentLayoutDisplayed];

            if (currentLayoutDisplayed == 0)
            {
                btnLast.Enabled = false;
            }
            btnNext.Enabled = true;

            //update picture
            image = new Bitmap(currentLayout.pictureFilename);
            picBox.Image = image;

            //update name, display file, IP address, Port Number
            lblName.Text = currentLayout.Name;
            lblFile.Text = currentLayout.layoutFile;
            lblAddress.Text = currentLayout.IPAddress;
            lblport.Text = currentLayout.Port;
        }

        private void startToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //call start server
            startServer();
        }

        private void stopToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //call stop server
            stopServer();
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            //call start server
            startServer();
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            //call stop server
            stopServer();
        }

        private void openLayoutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //display open layout screen
            LoadLayout aDlg = new LoadLayout();
            aDlg.ShowDialog();
            totalLayouts = Globals.GlobalTotalLayouts;
            currentLayoutDisplayed = totalLayouts - 1;
            if (totalLayouts > 0)
            {
                btnNext.Enabled = false;
                if (currentLayoutDisplayed == 0)
                {
                    btnLast.Enabled = false;
                }
                else
                {
                    btnLast.Enabled = true;
                }
                //get update arr
                arr = Globals.GlobalLayoutArr;
                currentLayout = arr[currentLayoutDisplayed];
                image = new Bitmap(currentLayout.pictureFilename);
                picBox.Image = image;
                lblName.Text = currentLayout.Name;
                lblFile.Text = currentLayout.layoutFile;
                lblAddress.Text = currentLayout.IPAddress;
                lblport.Text = currentLayout.Port;
            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ProgramExiting();
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            //display next layout
            currentLayoutDisplayed++;
            currentLayout = arr[currentLayoutDisplayed];

            if (currentLayoutDisplayed + 1 == totalLayouts)
            {
                btnNext.Enabled = false;
            }
            btnLast.Enabled = true;

            //update picture
            image = new Bitmap(currentLayout.pictureFilename);
            picBox.Image = image;

            //update name, display file, IP address, Port Number
            lblName.Text = currentLayout.Name;
            lblFile.Text = currentLayout.layoutFile;
            lblAddress.Text = currentLayout.IPAddress;
            lblport.Text = currentLayout.Port;
        }

        private void startServer()
        {
            //deactivate layout group box
            Properties.Settings.Default.Save();
            gbLayout.Enabled = false;
            workerThread.Start();
        }

        private void stopServer()
        {
            workerObject.RequestStop();
            gbLayout.Enabled = true;
        }

        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            About aDlg = new About();
            aDlg.ShowDialog();
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            ProgramExiting();
        }

        private void ProgramExiting()
        {
            //add data to SaveData
            data.saveData.arr = arr;
            data.saveData.currentLayout = currentLayout;
            data.saveData.currentLayoutDisplayed = currentLayoutDisplayed;
            data.saveData.globalArr = Globals.GlobalLayoutArr;
            data.saveData.globalTotalLayouts = Globals.GlobalTotalLayouts;
            data.saveData.image = image;
            data.saveData.totalLayouts = totalLayouts;
            
            //save data and port number
            data.ProgramSaveData();
            Properties.Settings.Default.PortNumber = int.Parse(txtPort.Text);
            Properties.Settings.Default.Save();
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            Globals.GlobalTempLayoutRecord = arr[currentLayoutDisplayed];
            EditWindow aDlg = new EditWindow();
            aDlg.ShowDialog();
            arr[currentLayoutDisplayed] = Globals.GlobalTempLayoutRecord;
            currentLayout = arr[currentLayoutDisplayed];
            image = new Bitmap(currentLayout.pictureFilename);
            picBox.Image = image;
            lblName.Text = currentLayout.Name;
            lblFile.Text = currentLayout.layoutFile;
            lblAddress.Text = currentLayout.IPAddress;
            lblport.Text = currentLayout.Port;
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
                totalLayouts--;
                for (int i = currentLayoutDisplayed + 1; i < totalLayouts; i++)
                {
                    arr[i - 1] = arr[i];
                }
                arr[totalLayouts].Name = "";
                arr[totalLayouts].IPAddress = "0.0.0.0";
                arr[totalLayouts].Port = "0000";
                arr[totalLayouts].layoutFile = "";
                arr[totalLayouts].pictureFilename = "";

                if (totalLayouts == 0)
                {
                    btnLast.Enabled = false;
                    btnNext.Enabled = false;
                    btnDelete.Enabled = false;
                    btnEdit.Enabled = false;
                }
                else if (totalLayouts - 1 == 0)
                {
                    btnLast.Enabled = false;
                    btnNext.Enabled = false;
                    btnDelete.Enabled = false;
                    btnEdit.Enabled = true;
                    currentLayoutDisplayed--;
                }
                else if (currentLayoutDisplayed == 0)
                {
                    btnLast.Enabled = false;
                    btnNext.Enabled = true;
                    btnDelete.Enabled = true;
                    btnEdit.Enabled = true;
                }
                else if (currentLayoutDisplayed == totalLayouts - 1)
                {
                    btnLast.Enabled = true;
                    btnNext.Enabled = false;
                    btnDelete.Enabled = true;
                    btnEdit.Enabled = true;
                }
                else
                {
                    btnLast.Enabled = true;
                    btnNext.Enabled = true;
                    btnDelete.Enabled = true;
                    btnEdit.Enabled = true;
                }
            //update screen
                if (totalLayouts > 0)
                {
                    currentLayout = arr[currentLayoutDisplayed];
                    image = new Bitmap(currentLayout.pictureFilename);
                    picBox.Image = image;
                    lblName.Text = currentLayout.Name;
                    lblFile.Text = currentLayout.layoutFile;
                    lblAddress.Text = currentLayout.IPAddress;
                    lblport.Text = currentLayout.Port;
                }
        }

        
    }

    public class Worker
    {
        int totalLayouts = Globals.GlobalTotalLayouts;
        LayoutRecord[] arr = Globals.GlobalLayoutArr;
        public void DoWork()
        {

            totalLayouts = Globals.GlobalTotalLayouts;
            arr = Globals.GlobalLayoutArr;
            IPEndPoint ipEnd = new IPEndPoint(IPAddress.Any, Properties.Settings.Default.PortNumber);
            Socket sock = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.IP);
            sock.Bind(ipEnd);
            sock.Listen(10);


            while (!_active)
            {
                try
                {
                    Socket socket = sock.Accept();
                    Stream s = new NetworkStream(socket);
                    StreamReader sr = new StreamReader(s);
                    StreamWriter sw = new StreamWriter(s);
                    //get command from socket
                    string recv = sr.ReadLine();
                    string command = recv.Substring(0, 3);
                    if (command == "REQ")
                    {
                        try
                        {
                            //reply with all layout data
                            string temp = totalLayouts.ToString();
                            sw.WriteLine(temp);
                            sw.Flush();
                            for (int j = 0; j < totalLayouts; j++)
                            {
                                /*sw.WriteLine(arr[j].Name);
                                sw.Flush();
                                //send iamge
                                byte[] fileData = File.ReadAllBytes(arr[j].pictureFilename);
                                int sent = SendVarData(socket, fileData);
                                /*----------------------------------------------
                                Bitmap bmp = new Bitmap(arr[j].pictureFilename);
                                MemoryStream ms = new MemoryStream();
                                bmp.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg);
                                byte[] bmpbytes = ms.ToArray();
                                bmp.Dispose();
                                ms.Close();
                                int sent = SendVarData(socket, bmpbytes);*/
                                MemoryStream ms = new MemoryStream();
                                byte[] Rbuffer = new byte[1024];
                                byte[] Tbyte;
                                Bitmap sImage = new Bitmap(arr[j].pictureFilename);
                                int iSize = sImage.Size.Height * sImage.Size.Width;
                                sImage.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg);
                                Tbyte = ms.ToArray();
                                s.Write(Tbyte, 0, Tbyte.Length);
                            }
                        }
                        catch
                        {
                            MessageBox.Show("Error sending files", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }

                    }
                    if (command == "LAY")
                    {
                        try
                        {
                            string temp2 = recv.Substring(4, 1);
                            int layoutNum = int.Parse(temp2);
                            //replay with layout data of layout number sent
                            LayoutRecord tempLayout = arr[layoutNum - 1];
                            //send layout name
                            sw.WriteLine(tempLayout.Name);
                            //send layout ip
                            sw.WriteLine(tempLayout.IPAddress);
                            //send layout port
                            sw.WriteLine(tempLayout.Port);
                            //send layout layoutfile
                            byte[] fileData = File.ReadAllBytes(tempLayout.layoutFile);
                            byte[] clientData = new byte[fileData.Length];
                            sw.WriteLine(fileData.Length);
                            sw.Flush();
                            s.Write(fileData, 0, fileData.Length);
                            s.Flush();
                            //send picture
                            fileData = File.ReadAllBytes(tempLayout.pictureFilename);
                            clientData = new byte[fileData.Length];
                            sw.WriteLine(fileData.Length);
                            sw.Flush();
                            s.Write(fileData, 0, fileData.Length);
                            s.Flush();
                        }
                        catch
                        {
                            MessageBox.Show("Error sending files", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }

                    }
                    socket.Disconnect(true);
                    socket.Close();
                }

                catch
                {
                    MessageBox.Show("Error accepting client connection", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            sock.Close();
        }
        public void RequestStop()
        {
            _active = true;
        }
        private volatile bool _active;

        private static int SendVarData(Socket s, byte[] data)
        {
            int total = 0;
            int size = data.Length;
            int dataleft = size;
            int sent;

            byte[] datasize = new byte[4];
            datasize = BitConverter.GetBytes(size);
            sent = s.Send(datasize);

            while (total < size)
            {
                sent = s.Send(data, total, dataleft, SocketFlags.None);
                total += sent;
                dataleft -= sent;
            }
            return total;
        }
    };
}
