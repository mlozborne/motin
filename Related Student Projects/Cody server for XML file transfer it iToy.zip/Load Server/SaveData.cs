﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Xml.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace Load_Server
{
    class SaveData
    {
        //serializable data
        [Serializable]
        public struct SaveProgramData
        {
            public int currentLayoutDisplayed;
            public int totalLayouts;
            public Bitmap image;
            public LayoutRecord[] arr;
            public LayoutRecord currentLayout;
            public int globalTotalLayouts;
            public LayoutRecord[] globalArr;
        }

        const string Filename = @"SavedData.bin";
        public SaveProgramData saveData;

        public void ProgramSaveData()
        {
            Stream FileStream = File.Create(Filename);
            BinaryFormatter serializer = new BinaryFormatter();
            serializer.Serialize(FileStream, saveData);
            FileStream.Close();
        }

        public int ProgramOpenData()
        {
            if (File.Exists(Filename))
            {
                Stream FileStream = File.OpenRead(Filename);
                BinaryFormatter deserializer = new BinaryFormatter();
                saveData = (SaveData.SaveProgramData)deserializer.Deserialize(FileStream);
                FileStream.Close();
                return 1;
            }
            else
            {
                saveData.currentLayoutDisplayed = 0;
                saveData.totalLayouts = 0;
                saveData.image = null;
                saveData.arr = null;
                saveData.globalTotalLayouts = 0;
                saveData.globalArr = null;
                return 0;
            }
        }
    }
}
