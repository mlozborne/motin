﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Load_Server
{
    [Serializable]
    public struct LayoutRecord
    {
        public string pictureFilename;
        public string Name;
        public string IPAddress;
        public string Port;
        public string layoutFile;
    }

    public static class Globals
    {
        static LayoutRecord[] _arr = new LayoutRecord[10];
        static int _totalLayouts = 0;
        static LayoutRecord _tempLayout;

        public static LayoutRecord[] GlobalLayoutArr
        {
            get
            {
                return _arr;
            }
            set
            {
                _arr = value;
            }
        }

        public static int GlobalTotalLayouts
        {
            get
            {
                return _totalLayouts;
            }
            set
            {
                _totalLayouts = value;
            }
        }

        public static LayoutRecord GlobalTempLayoutRecord
        {
            get
            {
                return _tempLayout;
            }
            set
            {
                _tempLayout = value;
            }
        }
    }
}
