﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Load_Server
{
    public partial class LoadLayout : Form
    {
        string pictureFileName;
        string layoutFileName;
        LayoutRecord[] arr;
        int totalLayouts;
        Bitmap image;

        public LoadLayout()
        {
            InitializeComponent();
            arr = Globals.GlobalLayoutArr;
            totalLayouts = Globals.GlobalTotalLayouts;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            //Open up picture dialog box
            OpenFileDialog aDlg = new OpenFileDialog();
            aDlg.FileName = "untitled";
            aDlg.Title = "Image of layout";
            aDlg.Filter = "JPG Files(*.jpg)" + "|*.jpg;|" + "jpg (*.jpg)|*.jpg";
            if (aDlg.ShowDialog() == DialogResult.OK)
            {
                pictureFileName = aDlg.FileName;
                image = new Bitmap(pictureFileName);
                picBox.Image = image;
            }
            
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            //Create new record and save it
            LayoutRecord record;
            record.Name = txtName.Text;
            record.IPAddress = txtIPAddress.Text;
            record.Port = txtPortNum.Text;
            record.layoutFile = layoutFileName;
            record.pictureFilename = pictureFileName;
            arr[totalLayouts] = record;
            Globals.GlobalLayoutArr = arr;
            Globals.GlobalTotalLayouts = totalLayouts + 1;
            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            //Close dialog without saving anything
            this.Close();
        }

        private void txtLayoutFile_Click(object sender, EventArgs e)
        {
            OpenFileDialog aDlg = new OpenFileDialog();
            aDlg.FileName = "untitled";
            aDlg.Title = "Layout Description File";
            aDlg.Filter = "XML Files(*.xml)" + "|*.xml|" + "xml(*.xml)|*.xml";
            if (aDlg.ShowDialog() == DialogResult.OK)
            {
                layoutFileName = aDlg.FileName;
            }
            txtLayoutFile.Text = layoutFileName;
        }
    }
}
