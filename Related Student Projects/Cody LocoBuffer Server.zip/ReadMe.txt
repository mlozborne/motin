MessageTranslationLibrary

Basically mine, but Cody added a couple of functions.

I need to merge this with my original.