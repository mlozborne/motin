#include <stdio.h>
#include <windows.h>
#include <string.h>
#include <conio.h>

static HANDLE hSerial;
static BOOL portOpen = 0;

int initializeCOMPort()
{
	int fail = 0;
	hSerial = CreateFile("COM3", GENERIC_READ | GENERIC_WRITE, 0, 0, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0);

	if (hSerial == INVALID_HANDLE_VALUE) //connection failed
		return 0;

	DCB dcbSerialParams = {0};
	dcbSerialParams.DCBlength = sizeof(dcbSerialParams);
	dcbSerialParams.BaudRate =  CBR_57600;
	dcbSerialParams.ByteSize = 8;
	dcbSerialParams.StopBits = ONESTOPBIT;
	dcbSerialParams.Parity = NOPARITY;
	dcbSerialParams.fOutxCtsFlow = 0;
	dcbSerialParams.fOutxDsrFlow = 0;
	dcbSerialParams.fOutX = 0;
	dcbSerialParams.fInX = 0;
	dcbSerialParams.fRtsControl = RTS_CONTROL_ENABLE;
	dcbSerialParams.fDtrControl = DTR_CONTROL_ENABLE;

	fail = SetCommState (hSerial, &dcbSerialParams);
	if (fail == 0) //SetCommState failed
		return 0;

	COMMTIMEOUTS timeouts = {0};
	timeouts.ReadIntervalTimeout = 100;
	timeouts.ReadTotalTimeoutConstant = 500;
	timeouts.ReadTotalTimeoutMultiplier = 100;
	timeouts.WriteTotalTimeoutConstant = 1000;
	timeouts.WriteTotalTimeoutMultiplier = 100;

	fail = SetCommTimeouts(hSerial, &timeouts);
	if (fail == 0) //setCommTimeouts failed
		return 0;

	//connection made
	portOpen = 1;
	return 1;
}

char readFromCOM()
{
	DWORD bytesRead;
	char read;
	BOOL readError;
	readError = ReadFile(hSerial, &read, 1, &bytesRead, NULL);
	return read;
}

void writeToCOM(char write)
{
	DWORD bytesWrote;
	BOOL writeError;
	writeError = WriteFile(hSerial, &write, 1, &bytesWrote, NULL);
	return;
}